<?php
/**
 * Search and AI-search visibility: page titles and descriptions written for "spa / salon in Buruburu, Nairobi"
 * searches, canonical links, link previews (WhatsApp, Facebook, X), schema.org data for Google and AI answer
 * engines (the business, its treatments, breadcrumbs, the FAQ), alt text on photos, /llms.txt (a plain summary
 * for AI assistants) and an IndexNow key so Bing (and the AI search built on it) picks up changes quickly.
 */

const AG_PLACE    = 'Buruburu, Nairobi';
const AG_STREET   = 'TJ&U Fitness Complex, 2nd floor, Rabai Road';
const AG_INDEXNOW = '6f1c2b8e4d7a49c3a5e0b9d2c8f4a713';

// What each page is about, for the description and the AI summary.
const AG_PAGE_SEO = [
	'book'          => 'Book a facial, massage, manicure, pedicure, braids or a spa package at Aura Glow Spa & Salon in Buruburu, Nairobi. Pick your treatments, choose a day and time, and we confirm on WhatsApp.',
	'price-list'    => 'Aura Glow Spa & Salon price list: HydraFacial KSh 7,000, massage from KSh 1,000, manicure from KSh 800, pedicure from KSh 1,000, braids from KSh 1,000, waxing, makeup and spa packages. Buruburu, Nairobi.',
	'gift-vouchers' => 'Give a spa day in Nairobi: Aura Glow gift vouchers from KSh 1,000 to KSh 10,000 for facials, massage, nails and hair at our Buruburu spa & salon on Rabai Road.',
	'shop'          => 'All 34 treatments at Aura Glow Spa & Salon, Buruburu: facials, massage and body treatments, nails, hair, waxing and brows, makeup and spa packages, with prices in KSh.',
];
const AG_HOME_TITLE = 'Aura Glow Spa & Salon | Spa & Beauty Salon in Buruburu, Nairobi';
const AG_HOME_DESC  = 'Luxury spa & salon on Rabai Road, Buruburu, Nairobi: HydraFacial and advanced facials, massage, Moroccan bath, steam, manicure, pedicure, braids, locs, waxing and makeup. Open Mon–Sat 8 am–8 pm. Call or WhatsApp 0722 358 594.';

function ag_seo_clean( $text, $len = 158 ) {
	$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES ) ) );
	return mb_strlen( $text ) > $len ? rtrim( mb_substr( $text, 0, $len - 1 ), " ,.;:–-" ) . '…' : $text;
}

function ag_seo_price_from( WC_Product $p ) {
	$price = $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price();
	return $price !== '' ? ag_money( $price ) : '';
}

function ag_seo_description() {
	if ( is_front_page() ) {
		return AG_HOME_DESC;
	}
	if ( is_product() && ( $p = wc_get_product( get_queried_object_id() ) ) ) {
		$from = ag_seo_price_from( $p );
		$text = $p->get_short_description() ?: $p->get_description();
		return ag_seo_clean( $p->get_name() . ( $from ? ' from ' . $from : '' ) . ' at Aura Glow Spa & Salon, ' . AG_PLACE . '. ' . ag_seo_clean( $text, 400 ) );
	}
	if ( is_product_category() ) {
		$t      = get_queried_object();
		$prices = array_filter( array_map( fn( $p ) => (float) ( $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price() ), ag_products_in( $t->slug ) ) );
		$intro  = ( $t->description ? rtrim( ag_seo_clean( $t->description, 300 ), '.' ) : html_entity_decode( $t->name ) ) . ' at Aura Glow Spa & Salon, ' . AG_PLACE . '.';
		return ag_seo_clean( $intro . ( $prices ? ' From ' . ag_money( min( $prices ) ) . '. Book online or WhatsApp ' . AG_PHONE . '.' : '' ) );
	}
	if ( is_shop() ) {
		return AG_PAGE_SEO['shop'];
	}
	if ( is_page() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		if ( isset( AG_PAGE_SEO[ $slug ] ) ) {
			return AG_PAGE_SEO[ $slug ];
		}
		$excerpt = ag_seo_clean( get_post_field( 'post_content', get_queried_object_id() ) );
		return $excerpt ?: AG_HOME_DESC;
	}
	return AG_HOME_DESC;
}

function ag_seo_canonical() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_shop() ) {
		$url = wc_get_page_permalink( 'shop' );
	} elseif ( is_product_category() || is_product_tag() ) {
		$url = get_term_link( get_queried_object() );
	} else {
		return ''; // Single pages and products: WordPress prints its own canonical.
	}
	$paged = (int) get_query_var( 'paged' );
	return $paged > 1 ? trailingslashit( $url ) . 'page/' . $paged . '/' : $url;
}

function ag_seo_image() {
	if ( is_product() && ( $p = wc_get_product( get_queried_object_id() ) ) && $p->get_image_id() ) {
		return wp_get_attachment_image_url( $p->get_image_id(), 'full' );
	}
	return get_stylesheet_directory_uri() . '/assets/og.jpg';
}

// Titles: brand plus place, which is what people search ("spa in Buruburu", "HydraFacial Nairobi").
add_filter( 'document_title_separator', fn() => '|' );
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_front_page() ) {
		return esc_html( AG_HOME_TITLE );
	}
	if ( is_product() || is_product_category() ) {
		$name = is_product() ? get_the_title( get_queried_object_id() ) : single_term_title( '', false );
		return esc_html( html_entity_decode( $name ) . ' in Buruburu, Nairobi | Aura Glow Spa & Salon' );
	}
	if ( is_page() || is_shop() ) {
		$name = get_the_title( is_shop() ? wc_get_page_id( 'shop' ) : get_queried_object_id() );
		return esc_html( html_entity_decode( $name ) . ' | Aura Glow Spa & Salon, Buruburu' );
	}
	return $title;
} );

add_action( 'wp_head', function () {
	$title = wp_get_document_title();
	$desc  = ag_seo_description();
	$canon = ag_seo_canonical();
	$url   = $canon ?: ( is_singular() ? get_permalink() : home_url( add_query_arg( [] ) ) );
	$img   = ag_seo_image();
	$tags  = [
		[ 'name', 'description', $desc ],
		[ 'property', 'og:type', is_product() ? 'product' : 'website' ],
		[ 'property', 'og:site_name', 'Aura Glow Spa & Salon' ],
		[ 'property', 'og:locale', 'en_KE' ],
		[ 'property', 'og:title', $title ],
		[ 'property', 'og:description', $desc ],
		[ 'property', 'og:url', $url ],
		[ 'property', 'og:image', $img ],
		[ 'property', 'og:image:alt', 'Aura Glow Spa & Salon, Buruburu, Nairobi' ],
		[ 'name', 'twitter:card', 'summary_large_image' ],
		[ 'name', 'twitter:title', $title ],
		[ 'name', 'twitter:description', $desc ],
		[ 'name', 'twitter:image', $img ],
		[ 'name', 'geo.region', 'KE-30' ],
		[ 'name', 'geo.placename', 'Buruburu, Nairobi' ],
		[ 'name', 'geo.position', AG_LAT . ';' . AG_LNG ],
	];
	foreach ( $tags as [ $attr, $key, $val ] ) {
		printf( "<meta %s=\"%s\" content=\"%s\">\n", $attr, esc_attr( $key ), esc_attr( $val ) );
	}
	if ( $canon ) {
		printf( "<link rel=\"canonical\" href=\"%s\">\n", esc_url( $canon ) );
	}
	echo '<link rel="alternate" type="text/plain" title="Aura Glow summary for AI assistants" href="' . esc_url( home_url( '/llms.txt' ) ) . "\">\n";
	foreach ( ag_seo_schema() as $graph ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
	}
}, 2 );

// schema.org: the business on every page; treatments on the home page; breadcrumbs; the FAQ on the booking page.
function ag_seo_business() {
	$home = home_url( '/' );
	return [
		'@type'                     => [ 'DaySpa', 'BeautySalon', 'NailSalon', 'HairSalon' ],
		'@id'                       => $home . '#business',
		'name'                      => 'Aura Glow Spa & Salon',
		'alternateName'             => 'Aura Glow Spa',
		'description'               => AG_HOME_DESC,
		'url'                       => $home,
		'logo'                      => get_stylesheet_directory_uri() . '/assets/emblem-dark.png',
		'image'                     => [ get_stylesheet_directory_uri() . '/assets/og.jpg', ag_photo( 'room-salon' ), ag_photo( 'room-facial' ), ag_photo( 'room-nails' ) ],
		'telephone'                 => AG_TEL,
		'priceRange'                => 'KSh 200 – KSh 20,000',
		'currenciesAccepted'        => 'KES',
		'paymentAccepted'           => 'Cash, M-Pesa',
		'address'                   => [
			'@type'           => 'PostalAddress',
			'streetAddress'   => AG_STREET,
			'addressLocality' => 'Buruburu',
			'addressRegion'   => 'Nairobi',
			'postalCode'      => '00515',
			'addressCountry'  => 'KE',
		],
		'geo'                       => [ '@type' => 'GeoCoordinates', 'latitude' => (float) AG_LAT, 'longitude' => (float) AG_LNG ],
		'hasMap'                    => AG_MAPS,
		'areaServed'                => [ 'Buruburu', 'Nairobi' ],
		'openingHoursSpecification' => [
			[
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ],
				'opens'     => '08:00',
				'closes'    => '20:00',
			],
		],
		'foundingDate'              => '2024-07',
		'sameAs'                    => [ AG_IG ],
		'parentOrganization'        => [ '@type' => 'Organization', 'name' => 'Tabby James and U Auto Limited' ],
		'potentialAction'           => [ '@type' => 'ReserveAction', 'target' => home_url( '/book/' ), 'name' => 'Book a treatment' ],
	];
}

function ag_seo_schema() {
	$home     = home_url( '/' );
	$business = ag_seo_business();
	$graph    = [
		[ '@type' => 'WebSite', '@id' => $home . '#website', 'url' => $home, 'name' => 'Aura Glow Spa & Salon', 'inLanguage' => 'en-KE', 'publisher' => [ '@id' => $home . '#business' ] ],
	];

	if ( is_front_page() ) {
		$catalog = [];
		foreach ( ag_categories() as $t ) {
			$offers = [];
			foreach ( ag_products_in( $t->slug ) as $p ) {
				$from     = $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price();
				$offers[] = [
					'@type'              => 'Offer',
					'url'                => $p->get_permalink(),
					'priceCurrency'      => 'KES',
					'price'              => (string) $from,
					'priceSpecification' => [ '@type' => 'PriceSpecification', 'minPrice' => (float) $from, 'priceCurrency' => 'KES' ],
					'itemOffered'        => [ '@type' => 'Service', 'name' => html_entity_decode( $p->get_name() ), 'description' => ag_seo_clean( $p->get_short_description(), 200 ) ],
				];
			}
			if ( $offers ) {
				$catalog[] = [ '@type' => 'OfferCatalog', 'name' => html_entity_decode( $t->name ), 'url' => get_term_link( $t ), 'itemListElement' => $offers ];
			}
		}
		$business['hasOfferCatalog'] = [ '@type' => 'OfferCatalog', 'name' => 'Treatments and prices', 'itemListElement' => $catalog ];
	}
	$graph[] = $business;

	// Breadcrumbs: Home › menu › treatment.
	$crumbs = [];
	if ( is_product() ) {
		$terms = get_the_terms( get_queried_object_id(), 'product_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$crumbs[] = [ html_entity_decode( $terms[0]->name ), get_term_link( $terms[0] ) ];
		}
		$crumbs[] = [ html_entity_decode( get_the_title( get_queried_object_id() ) ), get_permalink( get_queried_object_id() ) ];
	} elseif ( is_product_category() ) {
		$crumbs[] = [ html_entity_decode( single_term_title( '', false ) ), get_term_link( get_queried_object() ) ];
	} elseif ( is_page() && ! is_front_page() ) {
		$crumbs[] = [ html_entity_decode( get_the_title( get_queried_object_id() ) ), get_permalink( get_queried_object_id() ) ];
	}
	if ( $crumbs ) {
		array_unshift( $crumbs, [ 'Home', $home ] );
		$graph[] = [
			'@type'           => 'BreadcrumbList',
			'itemListElement' => array_map( fn( $c, $i ) => [ '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] ], $crumbs, array_keys( $crumbs ) ),
		];
	}

	if ( is_page( 'book' ) && ( $faq = ag_seo_faq() ) ) {
		$graph[] = [
			'@type'      => 'FAQPage',
			'mainEntity' => array_map( fn( $qa ) => [ '@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => $qa[1] ] ], $faq ),
		];
	}

	return [ [ '@context' => 'https://schema.org', '@graph' => $graph ] ];
}

// The questions and answers in the booking page's FAQ (templates/page-book.html).
function ag_seo_faq() {
	$html = (string) @file_get_contents( get_theme_file_path( 'templates/page-book.html' ) );
	preg_match_all( '#<summary>(.*?)</summary>(.*?)</details>#s', $html, $m, PREG_SET_ORDER );
	return array_map( fn( $x ) => [ ag_seo_clean( $x[1], 300 ), ag_seo_clean( $x[2], 1000 ) ], $m );
}

// Photos without alt text get the treatment's name (or the photo's title), so they show up in image search.
add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $attachment ) {
	if ( ! empty( $attr['alt'] ) || str_contains( $attr['class'] ?? '', 'ag-alt-img' ) ) {
		return $attr;
	}
	$parent      = get_post_parent( $attachment );
	$name        = $parent && $parent->post_type === 'product' ? $parent->post_title : $attachment->post_title;
	$attr['alt'] = html_entity_decode( $name ) . ' at Aura Glow Spa & Salon, Buruburu';
	return $attr;
}, 10, 2 );

// /llms.txt: a plain-text summary of the business and every treatment with its price, for AI assistants and
// AI search (ChatGPT, Perplexity, Gemini, Claude). /<IndexNow key>.txt proves the key to Bing.
add_action( 'template_redirect', function () {
	$path = trim( (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	if ( $path === AG_INDEXNOW . '.txt' ) {
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		exit( AG_INDEXNOW );
	}
	if ( $path !== 'llms.txt' ) {
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	$home = home_url( '/' );
	$out  = "# Aura Glow Spa & Salon\n\n> " . AG_HOME_DESC . "\n\n";
	$out .= "Aura Glow Spa & Salon is a day spa and beauty salon in Buruburu, Nairobi, Kenya, opened in July 2024. It is on the 2nd floor of the TJ&U Fitness Complex on Rabai Road, Buruburu Phase 1 (take the stairs past TJ & U Fitness on the 1st floor). It has a facial room, a massage room with a shower, steam and sauna, a salon with wash basins, a manicure bar, pedicure chairs and a private waxing room. It welcomes everyone, including men and children, and hosts bridal parties and groups.\n\n";
	$out .= "## Contact and booking\n\n";
	$out .= "- Phone and WhatsApp: " . AG_PHONE . " (+254 722 358 594)\n";
	$out .= "- Address: " . AG_STREET . ", Buruburu Phase 1, Nairobi, Kenya\n";
	$out .= "- Map: " . AG_MAPS . "\n";
	$out .= "- Hours: Monday to Saturday 8 am to 8 pm; closed on Sunday\n";
	$out .= "- Book online: " . home_url( '/book/' ) . " (choose treatments, a day and a time; confirmed on WhatsApp)\n";
	$out .= "- Instagram: " . AG_IG . "\n";
	$out .= "- Payment: M-Pesa or cash at the front desk after the treatment; nothing is paid online\n\n";
	$out .= "## Treatments and prices (Kenyan shillings)\n";
	foreach ( ag_categories( true ) as $t ) {
		$list = ag_products_in( $t->slug );
		if ( ! $list ) {
			continue;
		}
		$out .= "\n### " . html_entity_decode( $t->name ) . ' (' . get_term_link( $t ) . ")\n\n";
		foreach ( $list as $p ) {
			$min   = $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price();
			$max   = $p->is_type( 'variable' ) ? $p->get_variation_price( 'max' ) : $min;
			$price = $min === $max ? ag_money( $min ) : ag_money( $min ) . ' to ' . ag_money( $max );
			$out  .= '- [' . html_entity_decode( $p->get_name() ) . '](' . $p->get_permalink() . '): ' . $price . '. ' . ag_seo_clean( $p->get_short_description(), 220 ) . "\n";
		}
	}
	if ( $faq = ag_seo_faq() ) {
		$out .= "\n## Good to know\n\n";
		foreach ( $faq as [ $q, $a ] ) {
			$out .= "**$q** $a\n\n";
		}
	}
	$out .= "## Pages\n\n- [Home]($home)\n- [Price list](" . home_url( '/price-list/' ) . ")\n- [Book](" . home_url( '/book/' ) . ")\n- [Gift vouchers](" . home_url( '/gift-vouchers/' ) . ")\n- [All treatments](" . wc_get_page_permalink( 'shop' ) . ")\n";
	exit( $out );
}, 0 );

// Tell Bing (and through it Copilot and ChatGPT search) about changed pages straight away.
function ag_indexnow( array $urls ) {
	if ( wp_get_environment_type() !== 'production' || str_contains( home_url(), 'playground' ) || ! str_starts_with( home_url(), 'https://' ) ) {
		return;
	}
	wp_remote_post( 'https://api.indexnow.org/indexnow', [
		'blocking' => false,
		'headers'  => [ 'Content-Type' => 'application/json; charset=utf-8' ],
		'body'     => wp_json_encode( [ 'host' => wp_parse_url( home_url(), PHP_URL_HOST ), 'key' => AG_INDEXNOW, 'keyLocation' => home_url( '/' . AG_INDEXNOW . '.txt' ), 'urlList' => array_values( $urls ) ] ),
	] );
}
add_action( 'save_post', function ( $id, $post ) {
	if ( $post->post_status === 'publish' && in_array( $post->post_type, [ 'product', 'page' ], true ) && ! wp_is_post_revision( $id ) ) {
		ag_indexnow( [ get_permalink( $id ) ] );
	}
}, 20, 2 );

// Sitemap: only pages worth finding. Cart, checkout and account pages are noindex anyway, and the user list
// would show the admin login name.
add_filter( 'wp_sitemaps_add_provider', fn( $provider, $name ) => $name === 'users' ? false : $provider, 10, 2 );
add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	if ( $post_type === 'page' && function_exists( 'wc_get_page_id' ) ) {
		$args['post__not_in'] = array_merge( $args['post__not_in'] ?? [], array_filter( array_map( 'wc_get_page_id', [ 'cart', 'checkout', 'myaccount' ] ), fn( $id ) => $id > 0 ) );
	}
	return $args;
}, 10, 2 );
