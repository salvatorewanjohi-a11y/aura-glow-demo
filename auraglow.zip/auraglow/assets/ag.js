( function () {
	const cfg = window.AG || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const store = {
		get: ( k ) => {
			try {
				return JSON.parse( sessionStorage.getItem( k ) || 'null' );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				sessionStorage.setItem( k, JSON.stringify( v ) );
			} catch ( e ) {}
		},
	};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.ag-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'ag-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		// One toast at a time on phones, two on bigger screens: older ones make way.
		const max = window.innerWidth < 600 ? 1 : 2;
		while ( box.children.length >= max ) box.firstElementChild.remove();
		const t = document.createElement( 'div' );
		t.className = 'ag-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3400 );
		setTimeout( () => t.remove(), 3900 );
	}
	const addedMsg = () => '✦ Added to your appointment · <a href="' + esc( cfg.checkout || '/checkout/' ) + '">Choose day &amp; time</a>';
	document.body.addEventListener( 'wc-blocks_added_to_cart', ( e ) => {
		if ( ! ( e.detail && e.detail.agQuiet ) ) toast( addedMsg() );
	} );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( addedMsg() ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id, quantity = 1 ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		return cart;
	}
	// ids: treatments or chosen options. Opens the appointment drawer once everything is in.
	async function addToCart( ids, btn, quiet, quantity = 1 ) {
		if ( btn ) btn.disabled = true;
		try {
			let cart;
			for ( const id of [].concat( ids ) ) cart = await addItem( id, quantity );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true, detail: { agQuiet: !! quiet } } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			return true;
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your appointment. Please try again.' ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ag-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.agAdd, b );
	} );

	/* WhatsApp summary from the cart -------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-ag-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your appointment is empty.' );
				return;
			}
			const when = store.get( 'ag-booking' ) || {};
			const gift = store.get( 'ag-voucher' );
			const lines = [ 'Hi Aura Glow, I\'d like to book:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Total: ' + fmt( money( cart.totals.total_price, cart.totals ) ) );
			lines.push( 'Day: ' + ( when.dateLabel || '' ), 'Time: ' + ( when.slotLabel || '' ) );
			if ( gift ) lines.push( 'Voucher: ' + gift.text );
			lines.push( 'Name & phone: ' + ( when.name ? when.name + ', ' + when.phone : '' ) );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your appointment. Please try again.' );
		}
	} );

	/* Treatment page: option buttons -------------------------------------- */
	// Turns WooCommerce's option drop-downs into buttons that show each option's price (the drop-downs stay in
	// the form, hidden, so WooCommerce still swaps the price).
	function variationPrices( form ) {
		try {
			return JSON.parse( form.dataset.product_variations || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function initOptions() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.agSw ) return;
			sel.dataset.agSw = '1';
			const form = sel.closest( 'form' );
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			wrap.className = 'ag-sw';
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			const vars = variationPrices( form );
			wrap.innerHTML = opts.map( ( o ) => {
				const v = vars.find( ( x ) => x.attributes && x.attributes[ sel.name ] === o.value );
				return '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span>' + ( v ? '<small>' + esc( fmt( v.display_price ) ) + '</small>' : '' ) + '</button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'ag-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( form );
			} );
			paint();
			updateWaProduct( form );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The treatment page's WhatsApp button names the option the client picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-ag-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		const msg = 'Hi Aura Glow, I\'d like to book: ' + a.dataset.agWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.agWaPrice + ')' ) + '. ' + a.dataset.agWaUrl;
		a.href = waUrl( msg );
	}

	/* Details & video pop-up --------------------------------------------- */
	const choiceNames = ( p ) => ( p.attributes || [] ).filter( ( a ) => a.has_variations ).map( ( a ) => plain( a.name ).toLowerCase() );
	const QV_MAX = 10;
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-ag-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'ag-qv' );
		const body = dlg && dlg.querySelector( '[data-ag-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="ag-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.agQv ) ).json();
			const clip = b.dataset.agClip;
			const video = clip ? '<video src="' + esc( clip ) + '" muted loop playsinline autoplay></video>' : '';
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i || clip ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 || clip ? '<div class="ag-qv__thumbs">' + ( clip ? '<button type="button" class="ag-qv__pov" data-ag-qv-img="v">▶ Video</button>' : '' ) + p.images.map( ( im, i ) => '<button type="button" data-ag-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cats = p.categories && p.categories[ 0 ] ? plain( p.categories[ 0 ].name ) : '';
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View treatment</a>';
			} else if ( p.variations && p.variations.length && p.variations.length <= QV_MAX ) {
				choose = '<p class="ag-qv__label">' + esc( choiceNames( p ).join( ' & ' ) ) + ': <strong data-ag-qv-picked></strong></p><div class="ag-sw">' + p.variations.map( ( v, i ) => {
					const label = ( v.attributes || [] ).map( ( a ) => plain( a.value ) ).join( ' · ' );
					return '<button type="button" data-ag-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '><span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-ag-add="' + p.variations[ 0 ].id + '" data-ag-qv-buy>Add to my appointment</button>';
			} else if ( p.type === 'variable' ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p )[ 0 ] || 'options' ) + '</a>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-ag-add="' + p.id + '">Add to my appointment</button>';
			}
			body.innerHTML = '<div class="ag-qv__grid"><div class="ag-qv__media"><div class="ag-qv__main">' + video + imgs + '</div>' + thumbs + '</div>' +
				'<div class="ag-qv__info">' + ( cats ? '<p class="ag-eyebrow">' + esc( cats ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="ag-qv__price">' + p.price_html + '</div>' +
				'<div class="ag-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="ag-qv__actions">' + buy + '<a class="ag-link" href="' + esc( p.permalink ) + '">What\'s included →</a></div></div></div>';
			const first = body.querySelector( '[data-ag-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this treatment. Please try again.</p>';
		}
	} );
	// Option price: the Store API lists variations without it, so fetch the chosen one.
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-ag-qv-body]' );
		$$( '[data-ag-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-ag-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-ag-qv-buy]' );
		if ( buy ) buy.dataset.agAdd = btn.dataset.agQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.agQvVar ) ).json();
			// A slower reply for an earlier pick must not overwrite the current one.
			if ( ! btn.classList.contains( 'is-on' ) ) return;
			const price = box.querySelector( '.ag-qv__price' );
			if ( price && v.price_html ) price.innerHTML = v.price_html;
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ag-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-ag-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.ag-qv__media' );
		media.querySelectorAll( '.ag-qv__main img' ).forEach( ( im, i ) => ( im.hidden = String( i ) !== t.dataset.agQvImg ) );
		const v = media.querySelector( '.ag-qv__main video' );
		if ( v ) v.hidden = t.dataset.agQvImg !== 'v';
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.ag-dialog' ) ) e.target.close();
		// Close the call / WhatsApp menu when clicking elsewhere.
		$$( 'details.ag-contact[open]' ).forEach( ( d ) => {
			if ( ! d.contains( e.target ) ) d.open = false;
		} );
	} );
	// Stop the pop-up video when it closes.
	document.addEventListener( 'close', ( e ) => {
		if ( e.target.id === 'ag-qv' ) e.target.querySelector( '[data-ag-qv-body]' ).innerHTML = '';
	}, true );

	/* Tabs: price list, booking menus and gallery ------------------------ */
	function tabs( tabAttr, paneAttr ) {
		document.addEventListener( 'click', ( e ) => {
			const tab = e.target.closest( '[' + tabAttr + ']' );
			if ( ! tab ) return;
			const key = tab.getAttribute( tabAttr );
			const root = tab.parentElement.parentElement;
			$$( '[' + tabAttr + ']', tab.parentElement ).forEach( ( t ) => {
				t.classList.toggle( 'is-on', t === tab );
				t.setAttribute( 'aria-selected', t === tab ? 'true' : 'false' );
			} );
			$$( '[' + paneAttr + ']', root ).forEach( ( p ) => ( p.hidden = p.getAttribute( paneAttr ) !== key ) );
		} );
	}
	tabs( 'data-ag-tab', 'data-ag-pane' );
	tabs( 'data-ag-cat', 'data-ag-cat-pane' );
	tabs( 'data-ag-gtab', 'data-ag-gpane' );

	/* Gallery lightbox ---------------------------------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ag-lightbox]' );
		const dlg = document.getElementById( 'ag-lightbox' );
		if ( ! b || ! dlg || ! dlg.showModal ) return;
		dlg.querySelector( 'img' ).src = b.dataset.agLightbox;
		dlg.querySelector( 'img' ).alt = b.dataset.agCaption;
		dlg.querySelector( 'p' ).textContent = b.dataset.agCaption;
		dlg.showModal();
	} );

	/* Booking engine ------------------------------------------------------ */
	// Every treatment option and extra, by id: { name, opt, price, time, from }.
	function bookIndex() {
		const idx = {};
		( cfg.book.cats || [] ).forEach( ( c ) => c.items.forEach( ( it ) => ( idx[ it.id ] = { ...it, cat: c.name } ) ) );
		( cfg.book.addons || [] ).forEach( ( a ) => ( idx[ a.id ] = { name: a.name, opt: '', price: a.price, time: '', addon: true } ) );
		return idx;
	}
	const itemName = ( it ) => ( it.opt ? it.name + ': ' + it.opt : it.name );
	function readBooking( form, idx ) {
		const f = new FormData( form );
		const ids = [ ...f.getAll( 'item' ), ...f.getAll( 'addon' ) ].map( Number );
		const items = ids.map( ( id ) => ( { id, ...idx[ id ] } ) ).filter( ( i ) => i.name );
		const guests = Number( f.get( 'guests' ) || 1 );
		const each = items.reduce( ( s, i ) => s + i.price, 0 );
		const date = f.get( 'date' ) || '';
		const slot = f.get( 'slot' ) || '';
		return {
			items, guests, each, total: each * guests, from: items.some( ( i ) => i.from ),
			date, dateLabel: date ? cfg.book.dates[ date ] : '', slot, slotLabel: slot ? cfg.book.slots[ slot ] : '',
			name: String( f.get( 'name' ) || '' ).trim(), phone: String( f.get( 'phone' ) || '' ).trim(), email: String( f.get( 'email' ) || '' ).trim(), notes: String( f.get( 'notes' ) || '' ).trim(),
		};
	}
	function bookingText( r ) {
		return [
			'Hi Aura Glow, I\'d like to book:',
			...r.items.map( ( i ) => '• ' + itemName( i ) + ' – ' + ( i.from ? 'from ' : '' ) + fmt( i.price ) ),
			( r.guests > 1 ? 'For ' + cfg.book.guests[ r.guests ] + ' (' + fmt( r.each ) + ' each) · ' : '' ) + 'Subtotal: ' + ( r.from ? 'from ' : '' ) + fmt( r.total ),
			'Day: ' + ( r.dateLabel || 'flexible' ),
			'Time: ' + ( r.slotLabel || 'flexible' ),
			...( r.notes ? [ 'Preferences: ' + r.notes ] : [] ),
			'Name: ' + ( r.name || '' ) + ( r.phone ? ', ' + r.phone : '' ) + ( r.email ? ', ' + r.email : '' ),
		].join( '\n' );
	}
	function initBooking() {
		if ( ! cfg.book ) return;
		const idx = bookIndex();
		$$( '[data-ag-booking]' ).forEach( ( form ) => {
			const lines = form.querySelector( '[data-ag-book-lines]' );
			const total = form.querySelector( '[data-ag-book-total]' );
			const when = form.querySelector( '[data-ag-book-when]' );
			const wa = form.querySelector( '[data-ag-book-wa]' );
			const reserve = form.querySelector( '[data-ag-book-reserve]' );
			const steps = $$( '.ag-book__steps li', form );
			// Remember what was entered on this visit (the details also prefill checkout).
			const saved = store.get( 'ag-booking-form' );
			if ( saved ) {
				Object.entries( saved ).forEach( ( [ k, v ] ) => {
					$$( '[name="' + k + '"]', form ).forEach( ( el ) => {
						if ( el.type === 'checkbox' || el.type === 'radio' ) el.checked = [].concat( v ).map( String ).includes( el.value );
						else el.value = v;
					} );
				} );
			}
			const update = () => {
				const r = readBooking( form, idx );
				$$( '.ag-book__items label, .ag-book__addons label, .ag-book__slots label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				// How many are picked in each menu, on its tab.
				$$( '[data-ag-cat]', form ).forEach( ( t ) => {
					const n = $$( '[data-ag-cat-pane="' + t.dataset.agCat + '"] input:checked', form ).length;
					t.dataset.count = n || '';
				} );
				lines.innerHTML = r.items.length
					? r.items.map( ( i ) => '<li><span>' + esc( itemName( i ) ) + ( i.addon ? ' <em>extra</em>' : '' ) + '</span><b>' + ( i.from ? 'from ' : '' ) + esc( fmt( i.price ) ) + '</b></li>' ).join( '' ) + ( r.guests > 1 ? '<li class="ag-book__guests"><span>× ' + esc( cfg.book.guests[ r.guests ] ) + '</span><b>' + esc( fmt( r.each ) ) + ' each</b></li>' : '' )
					: '<li class="ag-book__empty">Choose a treatment to see your total.</li>';
				total.textContent = ( r.from ? 'from ' : '' ) + fmt( r.total );
				when.textContent = [ r.dateLabel, r.slotLabel ].filter( Boolean ).join( ' · ' );
				wa.href = waUrl( bookingText( r ) );
				store.set( 'ag-booking', { date: r.date, dateLabel: r.dateLabel, slot: r.slot, slotLabel: r.slotLabel, guests: String( r.guests ), notes: r.notes, name: r.name, phone: r.phone, email: r.email } );
				const keep = {};
				for ( const [ k, v ] of new FormData( form ) ) keep[ k ] = k in keep ? [].concat( keep[ k ], v ) : v;
				store.set( 'ag-booking-form', keep );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			form.addEventListener( 'change', ( e ) => {
				if ( e.target.name === 'item' && e.target.checked ) {
					const it = idx[ e.target.value ];
					// Options of one treatment (plain or gel manicure) replace each other.
					$$( 'input[name="item"]:checked', form ).forEach( ( other ) => {
						if ( other !== e.target && idx[ other.value ] && idx[ other.value ].name === it.name && idx[ other.value ].cat === it.cat ) {
							other.checked = false;
						}
					} );
					update();
					toast( '✦ ' + esc( itemName( it ) ) + ' added · ' + esc( fmt( it.price ) ) );
				}
			} );
			wa.addEventListener( 'click', ( e ) => {
				const r = readBooking( form, idx );
				if ( ! r.items.length ) {
					e.preventDefault();
					toast( 'Choose at least one treatment first.' );
					return;
				}
				toast( '✦ WhatsApp is opening with your booking summary. Tap send and we confirm your slot.' );
			} );
			reserve.addEventListener( 'click', async () => {
				const r = readBooking( form, idx );
				if ( ! r.items.length ) {
					toast( 'Choose at least one treatment first.' );
					form.querySelector( '[data-step="1"]' ).scrollIntoView( { behavior: 'smooth', block: 'start' } );
					return;
				}
				const label = reserve.textContent;
				reserve.textContent = 'Reserving…';
				// Reserving twice must not book the same treatment twice: skip what is already in the appointment.
				let have = [];
				try {
					have = ( ( await getCart() ).items || [] ).map( ( it ) => Number( it.id ) );
				} catch ( err ) {}
				const ids = r.items.map( ( i ) => i.id ).filter( ( id ) => ! have.includes( Number( id ) ) );
				const ok = ids.length ? await addToCart( ids, reserve, true, r.guests ) : true;
				reserve.textContent = label;
				if ( ok ) {
					toast( '✦ Appointment reserved' + ( r.dateLabel ? ' for ' + esc( r.dateLabel ) : '' ) + ' · <a href="' + esc( cfg.checkout ) + '">Confirm your details</a>' );
					setTimeout( () => ( window.location.href = cfg.checkout ), 1400 );
				}
			} );
			// Light up the step the client is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	/* Gift voucher maker -------------------------------------------------- */
	function initVoucher() {
		$$( '[data-ag-voucher]' ).forEach( ( form ) => {
			const out = ( k ) => form.querySelector( '[data-ag-v-' + k + ']' );
			const read = () => {
				const f = new FormData( form );
				const amount = form.querySelector( 'input[name="amount"]:checked' );
				return {
					id: amount ? Number( amount.value ) : 0, price: amount ? Number( amount.dataset.price ) : 0,
					occasion: f.get( 'occasion' ), send: f.get( 'send' ),
					to: String( f.get( 'to' ) || '' ).trim(), from: String( f.get( 'from' ) || '' ).trim(), message: String( f.get( 'message' ) || '' ).trim(),
				};
			};
			const text = ( v ) => fmt( v.price ) + ' ' + v.occasion.toLowerCase() + ' voucher' + ( v.to ? ' for ' + v.to : '' ) + ( v.from ? ' from ' + v.from : '' ) + ( v.message ? ': "' + v.message + '"' : '' ) + ' (send to ' + ( /Them/.test( v.send ) ? 'them' : 'me' ) + ')';
			const update = () => {
				const v = read();
				$$( '.ag-voucher__amounts label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				out( 'occasion' ).textContent = v.occasion;
				out( 'amount' ).textContent = fmt( v.price );
				out( 'to' ).textContent = v.to ? 'For ' + v.to : 'For someone special';
				out( 'msg' ).textContent = v.message || 'Happy birthday! Enjoy a day just for you.';
				out( 'from' ).textContent = v.from ? 'With love, ' + v.from : '';
				form.querySelector( '[data-ag-voucher-wa]' ).href = waUrl( 'Hi Aura Glow, I\'d like a gift voucher:\n• ' + text( v ) + '\nI\'ll pay by M-Pesa.' );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			form.querySelector( '[data-ag-voucher-add]' ).addEventListener( 'click', async ( e ) => {
				const v = read();
				if ( ! v.id ) return;
				store.set( 'ag-voucher', { text: text( v ) } );
				const ok = await addToCart( v.id, e.currentTarget, true );
				if ( ok ) toast( '✦ ' + esc( fmt( v.price ) ) + ' gift voucher added · <a href="' + esc( cfg.checkout ) + '">Check out</a>' );
			} );
			update();
		} );
	}

	/* Checkout: carry the day, time and voucher details from the booking engine */
	function prefillCheckout() {
		const b = store.get( 'ag-booking' );
		const gift = store.get( 'ag-voucher' );
		const data = window.wp && window.wp.data;
		if ( ( ! b && ! gift ) || ! data || ! document.querySelector( '.wp-block-woocommerce-checkout' ) ) return;
		let tries = 0;
		const timer = setInterval( () => {
			const checkout = data.dispatch( 'wc/store/checkout' );
			if ( ( checkout && checkout.setAdditionalFields ) || ++tries > 20 ) {
				clearInterval( timer );
				if ( ! checkout || ! checkout.setAdditionalFields ) return;
				const current = ( data.select( 'wc/store/checkout' ).getAdditionalFields && data.select( 'wc/store/checkout' ).getAdditionalFields() ) || {};
				const next = { ...current };
				if ( b ) {
					next[ 'ag/date' ] = current[ 'ag/date' ] || b.date || '';
					next[ 'ag/time' ] = current[ 'ag/time' ] || b.slot || '';
					next[ 'ag/guests' ] = current[ 'ag/guests' ] || b.guests || '1';
					next[ 'ag/notes' ] = current[ 'ag/notes' ] || b.notes || '';
				}
				if ( gift ) next[ 'ag/gift' ] = current[ 'ag/gift' ] || gift.text;
				checkout.setAdditionalFields( next );
			}
		}, 300 );
	}

	/* Studio clips: play only while on screen ---------------------------- */
	function initClips() {
		const vids = $$( '.ag-clip video, .ag-pdp-clip video' );
		if ( ! vids.length ) return;
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			vids.forEach( ( v ) => {
				v.removeAttribute( 'autoplay' );
				v.pause();
			} );
			return;
		}
		if ( ! ( 'IntersectionObserver' in window ) ) return;
		const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => {
			if ( en.isIntersecting ) en.target.play().catch( () => {} );
			else en.target.pause();
		} ), { rootMargin: '120px' } );
		vids.forEach( ( v ) => io.observe( v ) );
	}

	/* Home: mood hero ----------------------------------------------------- */
	const calm = !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
	const touch = !! ( window.matchMedia && window.matchMedia( '(hover: none)' ).matches );
	// A muted loop that only downloads when first needed; shown once it is actually playing.
	function playLoop( v ) {
		if ( ! v || calm ) return;
		if ( ! v.src && v.dataset.src ) {
			v.addEventListener( 'playing', () => v.classList.add( 'is-ready' ), { once: true } );
			v.src = v.dataset.src;
		}
		v.play().catch( () => {} );
	}
	function initHero() {
		const hero = document.querySelector( '[data-ag-hero]' );
		if ( ! hero ) return;
		const tabsEl = $$( '[data-ag-mood]', hero );
		const bar = hero.querySelector( '.ag-arch__bar i' );
		const CYCLE = 7000;
		let current = tabsEl[ 0 ].dataset.agMood;
		let timer = null;
		let user = false;
		let visible = true;
		const set = ( key ) => {
			current = key;
			tabsEl.forEach( ( t ) => {
				const on = t.dataset.agMood === key;
				t.classList.toggle( 'is-on', on );
				t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				t.tabIndex = on ? 0 : -1;
			} );
			$$( '[data-ag-mood-pane]', hero ).forEach( ( p ) => ( p.hidden = p.dataset.agMoodPane !== key ) );
			$$( '[data-ag-mood-media]', hero ).forEach( ( f ) => {
				const on = f.dataset.agMoodMedia === key;
				f.classList.toggle( 'is-on', on );
				const v = f.querySelector( 'video' );
				if ( on ) {
					if ( v ) v.currentTime = 0;
					playLoop( v );
				} else if ( v ) setTimeout( () => v.pause(), 1100 );
			} );
			runBar();
		};
		// The gold line under the arch counts down to the next mood until the visitor takes over.
		const runBar = () => {
			if ( ! bar ) return;
			bar.classList.remove( 'is-run' );
			void bar.offsetWidth;
			if ( ! user && ! calm ) bar.classList.add( 'is-run' );
		};
		const schedule = () => {
			clearTimeout( timer );
			if ( user || calm || ! visible || document.hidden ) return;
			timer = setTimeout( () => {
				const i = tabsEl.findIndex( ( t ) => t.dataset.agMood === current );
				set( tabsEl[ ( i + 1 ) % tabsEl.length ].dataset.agMood );
				schedule();
			}, CYCLE );
		};
		const takeOver = () => {
			if ( user ) return;
			user = true;
			clearTimeout( timer );
			if ( bar ) bar.parentElement.classList.add( 'is-off' );
		};
		hero.style.setProperty( '--ag-cycle', CYCLE + 'ms' );
		tabsEl.forEach( ( t, i ) => {
			t.tabIndex = i ? -1 : 0;
			t.addEventListener( 'click', () => {
				takeOver();
				set( t.dataset.agMood );
			} );
			// Arrow keys move between moods, as in any tab list.
			t.addEventListener( 'keydown', ( e ) => {
				const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ e.key ];
				if ( ! step ) return;
				e.preventDefault();
				const next = tabsEl[ ( i + step + tabsEl.length ) % tabsEl.length ];
				takeOver();
				set( next.dataset.agMood );
				next.focus();
			} );
		} );
		// Reading or adding a treatment pauses the carousel.
		hero.querySelector( '.ag-moods__panes' ).addEventListener( 'pointerenter', takeOver );
		hero.querySelector( '.ag-moods__panes' ).addEventListener( 'focusin', takeOver );
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( ( [ en ] ) => {
				visible = en.isIntersecting;
				const v = hero.querySelector( '.ag-arch__shot.is-on video' );
				if ( visible ) {
					playLoop( v );
					schedule();
				} else {
					clearTimeout( timer );
					if ( v ) v.pause();
				}
			} ).observe( hero );
		}
		document.addEventListener( 'visibilitychange', schedule );
		set( current );
		schedule();

		// The aura follows the pointer; on phones it drifts by itself.
		const aura = hero.querySelector( '.ag-hero2__aura' );
		if ( aura && ! calm ) {
			const move = ( x, y ) => {
				hero.style.setProperty( '--ag-x', x + 'px' );
				hero.style.setProperty( '--ag-y', y + 'px' );
			};
			if ( touch ) {
				const drift = () => move( hero.clientWidth * ( .15 + Math.random() * .7 ), hero.clientHeight * ( .15 + Math.random() * .7 ) );
				drift();
				setInterval( () => visible && drift(), 2600 );
				aura.style.transitionDuration = '2.6s';
			} else {
				hero.addEventListener( 'pointermove', ( e ) => {
					const r = hero.getBoundingClientRect();
					move( e.clientX - r.left, e.clientY - r.top );
				} );
			}
		}
	}

	/* Home: "+ Add" ticks the treatment in the booking engine ------------- */
	function initPicks() {
		const picks = $$( '[data-ag-pick]' );
		const form = document.querySelector( '[data-ag-booking]' );
		if ( ! picks.length ) return;
		const box = ( id ) => form && form.querySelector( 'input[name="item"][value="' + id + '"]' );
		const sync = () => picks.forEach( ( b ) => {
			const el = box( b.dataset.agPick );
			const on = !! ( el && el.checked );
			b.classList.toggle( 'is-added', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			b.querySelector( '.ag-pick__lbl' ).textContent = on ? 'Added' : 'Add';
		} );
		document.addEventListener( 'click', ( e ) => {
			const b = e.target.closest( '[data-ag-pick]' );
			if ( ! b ) return;
			e.preventDefault();
			const el = box( b.dataset.agPick );
			if ( ! el ) {
				addToCart( b.dataset.agPick, b );
				return;
			}
			el.checked = ! el.checked;
			// The booking engine does the maths, swaps options of the same treatment and shows the toast.
			el.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			if ( ! el.checked ) toast( esc( b.dataset.name ) + ' removed from your visit' );
			// Show the treatment's menu in the booking engine so it is there when they scroll down.
			const pane = el.closest( '[data-ag-cat-pane]' );
			const tab = pane && form.querySelector( '[data-ag-cat="' + pane.dataset.agCatPane + '"]' );
			if ( tab && pane.hidden ) tab.click();
			sync();
		} );
		if ( form ) form.addEventListener( 'change', sync );
		sync();
	}

	/* Floating "your visit" pill while treatments are picked -------------- */
	function initPill() {
		const form = document.querySelector( '[data-ag-booking]' );
		if ( ! form || ! document.querySelector( '[data-ag-hero]' ) ) return;
		const pill = document.createElement( 'a' );
		pill.className = 'ag-pill';
		pill.href = '#book';
		pill.innerHTML = '<span>✦ Your visit</span><span class="ag-pill__count"></span><b></b><span class="ag-pill__go">Choose a day →</span>';
		document.body.appendChild( pill );
		let near = false;
		const paint = () => {
			const n = $$( 'input[name="item"]:checked, input[name="addon"]:checked', form ).length;
			pill.querySelector( '.ag-pill__count' ).textContent = n + ( n === 1 ? ' treatment' : ' treatments' );
			pill.querySelector( 'b' ).textContent = form.querySelector( '[data-ag-book-total]' ).textContent;
			const on = n > 0 && ! near;
			pill.classList.toggle( 'is-on', on );
			pill.tabIndex = on ? 0 : -1;
			pill.setAttribute( 'aria-hidden', on ? 'false' : 'true' );
			document.body.classList.toggle( 'ag-has-pill', on );
		};
		form.addEventListener( 'change', () => setTimeout( paint ) );
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( ( [ en ] ) => {
				near = en.isIntersecting;
				paint();
			}, { rootMargin: '0px 0px -30% 0px' } ).observe( form );
		}
		pill.addEventListener( 'click', ( e ) => {
			e.preventDefault();
			const step = form.querySelector( '[data-step="3"]' );
			( step || form ).scrollIntoView( { behavior: calm ? 'auto' : 'smooth', block: 'start' } );
			const day = form.querySelector( 'select[name="date"]' );
			if ( day ) setTimeout( () => day.focus( { preventScroll: true } ), calm ? 0 : 700 );
		} );
		paint();
	}

	/* "Your visit" scroll story ------------------------------------------- */
	function initJourney() {
		const root = document.querySelector( '[data-ag-journey]' );
		if ( ! root ) return;
		const steps = $$( '[data-ag-step]', root );
		const imgs = $$( '[data-ag-step-img]', root );
		let shown = -1;
		// The step nearest the middle of the screen is the one being read.
		const pick = () => {
			const mid = window.innerHeight / 2;
			let best = 0;
			let dist = Infinity;
			steps.forEach( ( s, k ) => {
				const r = s.getBoundingClientRect();
				const d = Math.abs( r.top + r.height / 2 - mid );
				if ( d < dist ) {
					dist = d;
					best = k;
				}
			} );
			if ( best === shown ) return;
			shown = best;
			steps.forEach( ( s, k ) => s.classList.toggle( 'is-on', k === best ) );
			imgs.forEach( ( im, k ) => im.classList.toggle( 'is-on', k === best ) );
			root.style.setProperty( '--ag-p', ( ( best + 1 ) / steps.length * 100 ) + '%' );
		};
		let queued = false;
		window.addEventListener( 'scroll', () => {
			if ( queued ) return;
			queued = true;
			requestAnimationFrame( () => {
				queued = false;
				pick();
			} );
		}, { passive: true } );
		pick();
	}

	/* Treatment tiles: their loop plays on hover (on phones, while on screen) */
	function initTiles() {
		const tiles = $$( '.ag-service' ).filter( ( t ) => t.querySelector( 'video' ) );
		if ( ! tiles.length || calm ) return;
		const on = ( t ) => {
			const v = t.querySelector( 'video' );
			playLoop( v );
			v.addEventListener( 'playing', () => t.classList.add( 'is-playing' ), { once: true } );
			if ( v.classList.contains( 'is-ready' ) ) t.classList.add( 'is-playing' );
		};
		const off = ( t ) => {
			t.classList.remove( 'is-playing' );
			t.querySelector( 'video' ).pause();
		};
		if ( touch ) {
			if ( ! ( 'IntersectionObserver' in window ) ) return;
			const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => ( en.isIntersecting ? on( en.target ) : off( en.target ) ) ), { threshold: .7 } );
			tiles.forEach( ( t ) => io.observe( t ) );
		} else {
			tiles.forEach( ( t ) => {
				t.addEventListener( 'mouseenter', () => on( t ) );
				t.addEventListener( 'mouseleave', () => off( t ) );
			} );
		}
	}

	/* Marquee and section reveals ---------------------------------------- */
	function initMotion() {
		// A second copy of the names makes the marquee loop without a jump.
		$$( '.ag-marquee__track' ).forEach( ( t ) => ( t.innerHTML += t.innerHTML ) );
		if ( calm || ! ( 'IntersectionObserver' in window ) ) return;
		$$( 'main .ag-head, .ag-why__photo, .ag-why__cards .ag-card, .ag-prices, .ag-book, .ag-voucher, .ag-seen__card, .ag-gallery, .ag-faq, .ag-visit__grid > *' ).forEach( ( el ) => el.classList.add( 'ag-reveal' ) );
		document.documentElement.classList.add( 'ag-js' );
		const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => {
			if ( ! en.isIntersecting ) return;
			en.target.classList.add( 'is-in' );
			io.unobserve( en.target );
		} ), { rootMargin: '0px 0px -8% 0px' } );
		$$( '.ag-reveal' ).forEach( ( el ) => io.observe( el ) );
	}

	function init() {
		initOptions();
		initBooking();
		initVoucher();
		initClips();
		initHero();
		initPicks();
		initPill();
		initJourney();
		initTiles();
		initMotion();
		prefillCheckout();
		// The mini cart and checkout re-render client-side; keep the option buttons in place.
		new MutationObserver( () => initOptions() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
