<?php
/**
 * Aura Glow Spa & Salon child theme: hair, nails, advanced facials and body treatments on the 2nd floor of the
 * TJ&U Fitness Complex, Rabai Road, Buruburu, booked like a shop. Treatments are products (their options are
 * variations); the cart is the appointment, and checkout asks for the day, the time of day and any preferences.
 */

const AG_WHATSAPP = '254722358594'; // "Call or WhatsApp" number on their HydraFacial post and every flyer.
const AG_PHONE    = '0722 358 594';
const AG_TEL      = '+254722358594';
const AG_IG       = 'https://www.instagram.com/auraglow_spa/';
const AG_SALONIST = 'https://salonist.io/cs/s/TabbyJamesandUAutoLimited';
const AG_LAT      = '-1.278819'; // The pin in their Instagram bio.
const AG_LNG      = '36.871877';
const AG_MAPS     = 'https://www.google.com/maps/search/?api=1&query=-1.278819,36.871877';
const AG_HOURS    = 'Mon–Sat 8 am–8 pm · Sun closed';
const AG_FONTS    = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500&family=Mulish:wght@300;400;600;700&display=swap';

// Time of day for an appointment (the brief's morning / afternoon / evening). They open 8 am–8 pm, Monday to Saturday.
const AG_SLOTS = [ 'morning' => 'Morning (8–11 am)', 'midday' => 'Midday (11 am–2 pm)', 'afternoon' => 'Afternoon (2–5 pm)', 'evening' => 'Evening (5–8 pm)' ];
const AG_GUESTS = [ '1' => 'Just me', '2' => '2 people', '3' => '3 people', '4' => '4 people', '5' => '5 or more (bridal party or group)' ];
// Pampering extras in the booking engine: [ service, option, label ]. All are treatments on their own price list.
const AG_ADDONS = [
	[ 'back-shoulder-massage', 'Shoulder massage', 'Shoulder massage' ],
	[ 'brow-care', 'Threading', 'Brow threading' ],
	[ 'gel-tips-builder', 'Plain gel', 'Gel polish on natural nails' ],
	[ 'classic-facials', 'Facial scrubbing', 'Facial scrub' ],
	[ 'waxing', 'Lip & chin', 'Lip & chin wax' ],
	[ 'back-shoulder-massage', 'Back massage', 'Back massage' ],
	[ 'reflexology', null, 'Reflexology foot massage' ],
	[ 'wash-treatment', 'Leave-in treatment', 'Leave-in hair treatment' ],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'ag-fonts', AG_FONTS, [], null );
	wp_enqueue_style( 'ag', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'ag', $uri . '/assets/ag.js', [], filemtime( $dir . '/assets/ag.js' ), true );
	wp_localize_script( 'ag', 'AG', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => AG_WHATSAPP,
		'book'     => is_front_page() || is_page( [ 'book', 'gift-vouchers' ] ) ? ag_booking_data() : null,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'ag-fonts', AG_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

// New WooCommerce installs switch the store to "Coming soon" after setup.php has run, so visitors who aren't logged
// in get "Great things are on the horizon" instead of the treatments, the cart and the checkout. The site is live.
add_filter( 'pre_option_woocommerce_coming_soon', fn() => 'no' );
add_filter( 'woocommerce_coming_soon_exclude', '__return_true' );

function ag_wa_link( $text = '' ) {
	return 'https://wa.me/' . AG_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function ag_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

function ag_product( $slug ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	return $post ? wc_get_product( $post->ID ) : null;
}

/** Hair styles and skin tags have a starting price ("from"), confirmed before the treatment starts. */
function ag_is_quote( $product_id ) {
	return get_post_meta( $product_id, '_ag_quote', true ) === 'yes';
}

function ag_clip_url( $name ) {
	return $name ? get_stylesheet_directory_uri() . '/assets/clips/' . $name . '.mp4' : '';
}

function ag_photo( $name ) {
	return get_stylesheet_directory_uri() . '/assets/photos/' . $name . '.webp';
}

const AG_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/** "Label: value" lines staff type on the product screen, as label => value pairs. */
function ag_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_ag_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function ag_included( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_ag_included', true ) ) ) ) );
}

/** Names of the attributes a client chooses on a variable product, e.g. [ 'Massage' ]. */
function ag_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/**
 * Every bookable option of a treatment, in menu order: [ id, label (the option, or '' for a single price), price ].
 * Read from the products, so price edits in the admin show up in the price list and the booking engine.
 */
function ag_options( WC_Product $p ) {
	if ( ! $p->is_type( 'variable' ) ) {
		return $p->is_purchasable() ? [ [ 'id' => $p->get_id(), 'label' => '', 'price' => (float) $p->get_price() ] ] : [];
	}
	$out = [];
	foreach ( $p->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$out[] = [ 'id' => $vid, 'label' => implode( ', ', array_values( $v->get_attributes() ) ), 'price' => (float) $v->get_price() ];
	}
	return $out;
}

function ag_option_for( WC_Product $p, $label ) {
	foreach ( ag_options( $p ) as $o ) {
		if ( $label === null || $o['label'] === $label ) {
			return $o;
		}
	}
	return null;
}

function ag_categories( $with_vouchers = false ) {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	return array_values( array_filter( $terms, fn( $t ) => $with_vouchers || $t->slug !== 'gift-vouchers' ) );
}

function ag_products_in( $cat ) {
	return wc_get_products( [ 'category' => [ $cat ], 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
}

/** Treatments by menu, extras, days and times for the booking engine and the voucher maker (ag.js does the maths). */
function ag_booking_data() {
	$cats = [];
	foreach ( ag_categories() as $t ) {
		$items = [];
		foreach ( ag_products_in( $t->slug ) as $p ) {
			$name = html_entity_decode( $p->get_name(), ENT_QUOTES );
			$time = (string) get_post_meta( $p->get_id(), '_ag_time', true );
			foreach ( ag_options( $p ) as $o ) {
				$items[] = [ 'id' => $o['id'], 'name' => $name, 'opt' => $o['label'], 'price' => $o['price'], 'time' => $time, 'from' => ag_is_quote( $p->get_id() ) ];
			}
		}
		$cats[] = [ 'slug' => $t->slug, 'name' => html_entity_decode( $t->name, ENT_QUOTES ), 'items' => $items ];
	}
	$addons = [];
	foreach ( AG_ADDONS as [ $slug, $label, $name ] ) {
		$p = ag_product( $slug );
		$o = $p ? ag_option_for( $p, $label ) : null;
		if ( $o ) {
			$addons[] = [ 'id' => $o['id'], 'name' => $name, 'price' => $o['price'] ];
		}
	}
	$vouchers = [];
	$v        = ag_product( 'gift-voucher' );
	foreach ( $v ? ag_options( $v ) : [] as $o ) {
		$vouchers[] = [ 'id' => $o['id'], 'label' => $o['label'], 'price' => $o['price'] ];
	}
	return [ 'cats' => $cats, 'addons' => $addons, 'dates' => ag_booking_dates(), 'slots' => AG_SLOTS, 'guests' => AG_GUESTS, 'vouchers' => $vouchers ];
}

function ag_badges_html( WC_Product $product ) {
	$time = get_post_meta( $product->get_id(), '_ag_time', true );
	$perk = get_post_meta( $product->get_id(), '_ag_perk', true );
	$h    = ( $perk ? '<span class="ag-badge ag-badge--perk">' . esc_html( $perk ) . '</span>' : '' ) . ( $time ? '<span class="ag-badge">' . esc_html( $time ) . '</span>' : '' );
	return $h ? '<div class="ag-badges">' . $h . '</div>' : '';
}

// "From KSh 800" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="ag-from">From</span> ' . wc_price( $min );
}, 10, 2 );
// Starting prices on simple treatments (skin tags) read "From".
add_filter( 'woocommerce_get_price_html', fn( $html, $product ) => $product->is_type( 'simple' ) && ag_is_quote( $product->get_id() ) ? '<span class="ag-from">From</span> ' . $html : $html, 10, 2 );

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to my appointment' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	$choices = ag_choices( $p );
	return $choices ? 'Choose ' . strtolower( $choices[0] ) : 'Book this';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Taking appointments · ' . AG_HOURS : 'Fully booked', 10, 2 );

/* -------------------------------------------------------------------------
 * Treatment page
 * ---------------------------------------------------------------------- */

// Benefit badges, time and key facts above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$perks = array_filter( array_map( 'trim', explode( '|', (string) get_post_meta( $id, '_ag_perks', true ) ) ) );
	$time  = get_post_meta( $id, '_ag_time', true );
	echo '<div class="ag-tags">';
	foreach ( $perks as $perk ) {
		echo '<span class="ag-tag">' . esc_html( $perk ) . '</span>';
	}
	echo ( $time ? '<span class="ag-tag ag-tag--time">' . esc_html( $time ) . '</span>' : '' ) . '</div>';
	if ( ag_is_quote( $id ) ) {
		echo '<p class="ag-note"><strong>Starting price.</strong> Length, size and style change it; we confirm the price with you before we begin.</p>';
	}
	$keys = array_slice( ag_specs( $id ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="ag-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Book on WhatsApp, the studio clip, pairings and promises under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . ag_money( $product->get_variation_price( 'min' ) ) : ag_money( $product->get_price() );
	$msg   = 'Hi Aura Glow, I\'d like to book: ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="ag-wa-order" data-ag-wa-product="' . esc_attr( $product->get_name() ) . '" data-ag-wa-price="' . esc_attr( $price ) . '" data-ag-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( ag_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . AG_WA_ICON . 'Book on WhatsApp</a>';

	$clip = get_post_meta( $product->get_id(), '_ag_clip', true );
	if ( $clip ) {
		echo '<figure class="ag-pdp-clip"><video src="' . esc_url( ag_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', ag_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>Filmed at Aura Glow ·<a href="' . esc_url( AG_IG ) . '" target="_blank" rel="noopener">more on Instagram</a></figcaption></figure>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="ag-pairs"><p class="ag-pairs__title">Pairs beautifully with</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="ag-pairs__add" data-ag-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to your appointment">+ Add</button>'
				: '<a class="ag-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="ag-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="ag-promise"><div><span aria-hidden="true">✦</span><p><strong>Your skin or hair first</strong>We look and ask before we start, and recommend only what it needs.</p></div><div><span aria-hidden="true">⌂</span><p><strong>2nd floor, TJ&amp;U Fitness Complex</strong>Rabai Road, Buruburu Phase 1. ' . esc_html( AG_HOURS ) . '.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay after your treatment</strong>By M-Pesa or cash at the front desk. Nothing is paid online.</p></div></div>';
} );

// What's included, and booking & payment tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return $tabs;
	}
	$id       = $product->get_id();
	$specs    = ag_specs( $id );
	$included = ag_included( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'About this treatment';
	}
	if ( $specs || $included ) {
		$tabs['ag_included'] = [
			'title'    => 'What\'s included',
			'priority' => 5,
			'callback' => function () use ( $specs, $included ) {
				echo '<div class="ag-sheet">';
				if ( $included ) {
					echo '<div><h3>Your treatment</h3><ul class="ag-checks">';
					foreach ( $included as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ul></div>';
				}
				echo '<div><h3>Good to know</h3><table class="ag-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div></div>';
			},
		];
	}
	$tabs['ag_booking'] = [
		'title'    => 'Booking & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Book online:</strong> add the treatment, then choose the day and the time of day at checkout, or use our <a href="' . esc_url( home_url( '/book/' ) ) . '">booking page</a>. We call or WhatsApp to confirm your slot.</li><li><strong>Where:</strong> TJ&amp;U Fitness Complex, 2nd floor, Rabai Road, Buruburu Phase 1 (<a href="' . esc_url( AG_MAPS ) . '" target="_blank" rel="noopener">map</a>). Take the stairs past the gym on the 1st floor.</li><li><strong>Hours:</strong> ' . esc_html( AG_HOURS ) . '.</li><li><strong>Pay:</strong> by M-Pesa or cash after your treatment. Bridal makeup, micro shading, sisterlocks, packages and gift vouchers take an M-Pesa deposit.</li><li><strong>WhatsApp:</strong> prefer to chat? Message ' . esc_html( AG_PHONE ) . '.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Treatment cards
 * ---------------------------------------------------------------------- */

function ag_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo), the video badge and the details pop-up on card images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = ag_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'ag-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$clip  = get_post_meta( $product->get_id(), '_ag_clip', true );
	$extra = ( $clip ? '<span class="ag-pov" aria-hidden="true">▶ Watch</span>' : '' )
		. sprintf( '<button type="button" class="ag-qv-btn" data-ag-qv="%1$d" data-ag-clip="%3$s" aria-label="Details of %2$s">%4$s</button>', $product->get_id(), esc_attr( $product->get_name() ), esc_url( ag_clip_url( $clip ) ), $clip ? 'Details &amp; video' : 'Quick view' );
	$pos   = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Label above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = ag_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_ag_badge', true ) : '';
	return ( $badge ? '<p class="ag-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Benefit and time badges, and "starting price" on hair styles and skin tags.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = ag_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$quote = ag_is_quote( $product->get_id() ) ? '<p class="ag-quote-note">Starting price · confirmed before we begin</p>' : '';
	return ag_badges_html( $product ) . $content . $quote;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page sections
 * ---------------------------------------------------------------------- */

// Treatment menus: one tile per category, with the photo of its first treatment.
add_shortcode( 'ag_services', function () {
	$sub = [
		'facials'      => 'HydraFacial · High frequency · Classic facials',
		'massage-body' => 'Massage · Moroccan bath · Scrub & steam · Thai stretch',
		'nails'        => 'Manicures · Jelly soak pedicure · Gel · Acrylics',
		'hair'         => 'Knotless & box braids · Twists · Locs · Treatments',
		'waxing-brows' => 'Underarm to Brazilian · Vajacial · Brows · Micro shading',
		'makeup'       => 'Everyday · Full glam · Special occasion · Bridal',
		'packages'     => 'Glow Trio · Body ritual · Couples · Bridal Glow',
	];
	// Menus whose treatments have no footage of their own show one of their room or client photos, not a brand card.
	$photo = [ 'waxing-brows' => 'tour-massage', 'makeup' => 'look-glam' ];
	// A loop from their reels plays over the photo while the tile is hovered or, on phones, on screen.
	$clip = [ 'facials' => 'hydra', 'massage-body' => 'massage', 'nails' => 'nails', 'hair' => 'braids', 'packages' => 'moroccan' ];
	$h    = '<div class="ag-services">';
	foreach ( ag_categories() as $t ) {
		$list = ag_products_in( $t->slug );
		$img  = isset( $photo[ $t->slug ] )
			? '<img src="' . esc_url( ag_photo( $photo[ $t->slug ] ) ) . '" alt="" loading="lazy" width="720" height="900">'
			: ( $list ? reset( $list )->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '' );
		if ( isset( $clip[ $t->slug ] ) ) {
			$img .= '<video data-src="' . esc_url( ag_clip_url( $clip[ $t->slug ] ) ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		}
		$h .= sprintf(
			'<a class="ag-service ag-service--%s ag-reveal" href="%s"><span class="ag-service__img">%s</span><span class="ag-service__txt"><strong>%s</strong><em>%s</em><span>%d treatments →</span></span></a>',
			esc_attr( $t->slug ),
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? '' ),
			count( $list )
		);
	}
	return $h . '</div>';
} );

/*
 * Home "Our treatments": one card per menu (packages have their own band), no prices: those live on the price
 * list. A loop from their reels plays over the photo on hover where the menu has one.
 */
add_shortcode( 'ag_offerings', function () {
	// [ line, theme photo instead of the first treatment's photo, clip ]
	$about = [
		'facials'      => [ 'Advanced facials for skin that looks rested and clear', '', 'hydra' ],
		'massage-body' => [ 'Massage, Moroccan bath, scrub, steam and stretch', '', 'massage' ],
		'nails'        => [ 'Manicures, jelly soak pedicures, gel and acrylics', '', 'nails' ],
		'hair'         => [ 'Braids, twists, locs and treatments at the basin', '', 'braids' ],
		'waxing-brows' => [ 'Smooth skin and defined brows, in a private room', 'room-waxing', '' ],
		'makeup'       => [ 'From everyday polish to full bridal glam', 'look-glam', '' ],
	];
	$h = '<div class="ag-offerings">';
	foreach ( ag_categories() as $t ) {
		if ( ! isset( $about[ $t->slug ] ) ) {
			continue;
		}
		[ $line, $photo, $clip ] = $about[ $t->slug ];
		$list = ag_products_in( $t->slug );
		// The first treatment's photo, or a room or client photo for menus without footage of their own.
		$img = $photo
			? '<img src="' . esc_url( ag_photo( $photo ) ) . '" alt="' . esc_attr( html_entity_decode( $t->name ) . ' at Aura Glow Spa & Salon, Buruburu' ) . '" loading="lazy" width="720" height="900">'
			: ( $list ? reset( $list )->get_image( 'woocommerce_single', [ 'loading' => 'lazy', 'alt' => '' ] ) : '' );
		$vid = $clip ? '<video data-src="' . esc_url( ag_clip_url( $clip ) ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>' : '';
		$h  .= sprintf(
			'<a class="ag-offering ag-reveal" href="%s"><span class="ag-offering__img">%s%s</span><span class="ag-offering__txt"><strong>%s</strong><span>%s</span><em>Discover <span aria-hidden="true">→</span></em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			$vid,
			esc_html( $t->name ),
			esc_html( $line )
		);
	}
	return $h . '</div>';
} );

/* Home "Signature package" band: one package with its price and what's in it, like a featured offer. */
add_shortcode( 'ag_offer', function ( $atts ) {
	$p = ag_product( shortcode_atts( [ 'slug' => 'glow-trio' ], $atts )['slug'] );
	$o = $p ? ag_option_for( $p, null ) : null;
	if ( ! $o ) {
		return '';
	}
	$items = array_slice( ag_included( $p->get_id() ), 0, 4 );
	$time  = (string) get_post_meta( $p->get_id(), '_ag_time', true );
	ob_start();
	?>
	<section class="ag-offer ag-dark">
		<div class="ag-title"><span class="ag-rule" aria-hidden="true"></span><p class="ag-label">Signature package</p><h2><?php echo esc_html( html_entity_decode( $p->get_name(), ENT_QUOTES ) ); ?></h2><p><?php echo esc_html( wp_strip_all_tags( $p->get_short_description() ) ); ?></p></div>
		<div class="ag-offer__card">
			<div class="ag-offer__img"><?php echo $p->get_image( 'woocommerce_single', [ 'alt' => '', 'loading' => 'lazy' ] ); ?><span class="ag-offer__tag">Best value<?php echo $time ? ' · ' . esc_html( $time ) : ''; ?></span></div>
			<div class="ag-offer__txt">
				<h3>Head-to-toe glow for <?php echo esc_html( ag_money( $o['price'] ) ); ?></h3>
				<ul><?php foreach ( $items as $it ) echo '<li>' . esc_html( $it ) . '</li>'; ?></ul>
				<div class="ag-offer__ctas"><button type="button" class="ag-btn-solid ag-btn-solid--sage" data-ag-add="<?php echo (int) $o['id']; ?>">Book this package</button><a class="ag-link-arrow ag-link-arrow--dark" href="<?php echo esc_url( $p->get_permalink() ); ?>">What's included <span aria-hidden="true">→</span></a></div>
			</div>
		</div>
		<p class="ag-center"><a class="ag-link-arrow" href="/product-category/packages/">See all packages <span aria-hidden="true">→</span></a></p>
	</section>
	<?php
	return ob_get_clean();
} );

/* Home "Step inside": a slide per room of the studio, tabs underneath, like a tour of the floor. */
const AG_ROOMS = [
	'desk'    => [ 'Front desk', 'Your welcome', 'Where every visit starts: a warm hello, a check of your booking and a minute to talk through what you would like.' ],
	'facial'  => [ 'Facial room', 'Skin & glow', 'A reclining facial bed, steam and soft light for HydraFacials, high-frequency and classic facials.' ],
	'salon'   => [ 'Salon', 'Hair', 'Round mirrors, styling chairs and wash basins for braids, twists, locs and treatments under the steamer.' ],
	'nails'   => [ 'Nail bar', 'Hands & feet', 'The manicure bar and pedicure chairs, for gel, tips, acrylics and our lavender jelly soak.' ],
	'massage' => [ 'Massage room', 'Body', 'A private room with robes and a shower, for full-body, hot stone and aromatherapy massage.' ],
	'waxing'  => [ 'Waxing & scrub room', 'Smooth skin', 'A private room for waxing, vajacials and head-to-toe body scrubs.' ],
];

add_shortcode( 'ag_rooms', function () {
	$slides = $tabs = '';
	$i      = 0;
	foreach ( AG_ROOMS as $key => [ $name, $label, $text ] ) {
		$slides .= sprintf(
			'<figure class="ag-room%1$s" id="ag-room-%2$s" role="tabpanel" aria-label="%3$s" data-ag-room="%4$d"%5$s><div class="ag-room__txt"><span class="ag-rule ag-rule--left" aria-hidden="true"></span><p class="ag-label">%6$s</p><h3>%3$s</h3><p>%7$s</p><a class="ag-link-arrow" href="/book/">Book a visit <span aria-hidden="true">→</span></a></div><img src="%8$s" alt="%3$s at Aura Glow" width="720" height="900" loading="lazy"></figure>',
			$i ? '' : ' is-on',
			esc_attr( $key ),
			esc_html( $name ),
			$i,
			$i ? ' hidden' : '',
			esc_html( $label ),
			esc_html( $text ),
			esc_url( ag_photo( 'room-' . $key ) )
		);
		$tabs .= sprintf( '<button type="button" role="tab" aria-controls="ag-room-%1$s" aria-selected="%2$s" data-ag-room-tab="%3$d"%4$s>%5$s</button>', esc_attr( $key ), $i ? 'false' : 'true', $i, $i ? '' : ' class="is-on"', esc_html( $name ) );
		$i++;
	}
	return '<div class="ag-rooms" data-ag-rooms><div class="ag-rooms__stage">' . $slides . '<button type="button" class="ag-rooms__arrow ag-rooms__arrow--prev" data-ag-room-step="-1" aria-label="Previous room">‹</button><button type="button" class="ag-rooms__arrow ag-rooms__arrow--next" data-ag-room-step="1" aria-label="Next room">›</button></div><div class="ag-rooms__tabs" role="tablist" aria-label="Rooms">' . $tabs . '</div></div>';
} );

/*
 * Hero: "How do you want to feel today?" Four moods, each with a loop from their reels in the arch and three
 * treatments that tick straight into the booking engine below. Prices are read from the products.
 * [ mood => [ button, line, caption, [ [ slug, option label or null ], … ] ] ]
 */
const AG_MOODS = [
	'unwind' => [ 'Unwind', 'Let the week <em>melt</em> away.', 'Full-body massage in our massage room', [ [ 'massage', 'Swedish massage' ], [ 'moroccan-bath', null ], [ 'steam-sauna', null ] ] ],
	'glow'   => [ 'Glow', 'Skin that looks <em>rested</em>, even when you aren\'t.', 'A full facial in our facial room', [ [ 'hydrafacial', null ], [ 'classic-facials', 'Full facial' ], [ 'high-frequency-facial', null ] ] ],
	'polish' => [ 'Get ready', 'Ready for the weekend, the photos, the <em>big day</em>.', 'Gel manicure at our manicure bar', [ [ 'manicure', 'Manicure with gel' ], [ 'jelly-soak-pedicure', null ], [ 'makeup', 'Full glam' ] ] ],
	'treat'  => [ 'Treat someone', 'Self-care is <em>better</em> together.', 'Lavender jelly soak at our pedicure chairs', [ [ 'couples-side-by-side', 'Side-by-side manicure & pedicure (for two)' ], [ 'glow-trio', null ], [ 'gift-voucher', null ] ] ],
];

function ag_mood_url( $name, $ext ) {
	return get_stylesheet_directory_uri() . '/assets/moods/' . $name . '.' . $ext;
}

add_shortcode( 'ag_hero', function () {
	$tabs = $panes = $media = '';
	$i    = 0;
	foreach ( AG_MOODS as $key => [ $label, $line, $caption, $picks ] ) {
		$on    = $i === 0;
		$tabs .= sprintf( '<button type="button" role="tab" id="ag-mood-%1$s" aria-controls="ag-mood-pane-%1$s" aria-selected="%2$s" data-ag-mood="%1$s"%3$s><span>%4$s</span></button>', esc_attr( $key ), $on ? 'true' : 'false', $on ? ' class="is-on"' : '', esc_html( $label ) );
		$cards = '';
		foreach ( $picks as [ $slug, $opt ] ) {
			$p = ag_product( $slug );
			if ( ! $p ) {
				continue;
			}
			$time = (string) get_post_meta( $p->get_id(), '_ag_time', true );
			$img  = $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] );
			if ( $slug === 'gift-voucher' ) {
				// A voucher needs an amount and a message: send them to the voucher maker.
				$cards .= '<li class="ag-pick"><a class="ag-pick__img" href="#vouchers">' . $img . '</a><div class="ag-pick__txt"><strong>Gift voucher</strong><small>From KSh 1,000 · sent on WhatsApp</small></div><a class="ag-pick__add" href="#vouchers">Make one</a></li>';
				continue;
			}
			$o = ag_option_for( $p, $opt );
			if ( ! $o ) {
				continue;
			}
			$name   = $opt ? $opt : html_entity_decode( $p->get_name(), ENT_QUOTES );
			$cards .= sprintf(
				'<li class="ag-pick"><a class="ag-pick__img" href="%1$s">%2$s</a><div class="ag-pick__txt"><a href="%1$s"><strong>%3$s</strong></a><small>%4$s%5$s</small></div><button type="button" class="ag-pick__add" data-ag-pick="%6$d" data-name="%3$s" aria-pressed="false"><span class="ag-pick__plus" aria-hidden="true">+</span><span class="ag-pick__lbl">Add</span></button></li>',
				esc_url( $p->get_permalink() ),
				$img,
				esc_html( $name ),
				esc_html( ag_money( $o['price'] ) ),
				$time ? ' · ' . esc_html( $time ) : '',
				(int) $o['id']
			);
		}
		$panes .= sprintf( '<div class="ag-mood" id="ag-mood-pane-%1$s" role="tabpanel" aria-labelledby="ag-mood-%1$s" data-ag-mood-pane="%1$s"%2$s><p class="ag-mood__line">%3$s</p><ul class="ag-mood__picks">%4$s</ul></div>', esc_attr( $key ), $on ? '' : ' hidden', wp_kses( $line, [ 'em' => [] ] ), $cards );
		$media .= sprintf(
			'<figure class="ag-arch__shot%1$s" data-ag-mood-media="%2$s"><img src="%3$s" alt="" width="600" height="800"%4$s><video data-src="%5$s" muted loop playsinline preload="none" poster="%3$s"></video><figcaption>%6$s</figcaption></figure>',
			$on ? ' is-on' : '',
			esc_attr( $key ),
			esc_url( ag_mood_url( $key, 'webp' ) ),
			$on ? ' fetchpriority="high"' : ' loading="lazy"',
			esc_url( ag_mood_url( $key, 'mp4' ) ),
			esc_html( $caption )
		);
		$i++;
	}
	$ring = 'AURA GLOW · SPA &amp; SALON · RABAI ROAD · ';
	ob_start();
	?>
	<section class="ag-hero2 ag-dark" data-ag-hero>
		<div class="ag-hero2__aura" aria-hidden="true"></div>
		<div class="ag-wrap ag-hero2__grid">
			<div class="ag-hero2__copy">
				<p class="ag-eyebrow">Spa &amp; salon · 2nd floor, TJ&amp;U Fitness Complex</p>
				<h1 class="ag-hero2__title">How do you want to <em>feel</em> today?</h1>
				<div class="ag-moods" role="tablist" aria-label="Choose a mood"><?php echo $tabs; ?></div>
				<div class="ag-moods__panes" aria-live="polite"><?php echo $panes; ?></div>
				<p class="ag-hero2__foot">Tap <b>+ Add</b> and it goes straight into your booking below. Or <a href="#prices">see the full menu</a> · Call or WhatsApp <a href="tel:<?php echo esc_attr( AG_TEL ); ?>"><?php echo esc_html( AG_PHONE ); ?></a></p>
			</div>
			<div class="ag-hero2__art">
				<div class="ag-arch"><?php echo $media; ?><span class="ag-arch__bar" aria-hidden="true"><i></i></span></div>
				<svg class="ag-ring" viewBox="0 0 200 200" aria-hidden="true"><defs><path id="ag-ring-path" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0"/></defs><text><textPath href="#ag-ring-path"><?php echo $ring . $ring; ?></textPath></text></svg>
				<img class="ag-ring__mark" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/emblem.png' ); ?>" alt="" width="320" height="276">
			</div>
		</div>
		<div class="ag-wrap">
			<ul class="ag-trust">
				<li><span>✦</span><div><strong>Advanced skin &amp; facial tech</strong>HydraFacial, high frequency, LED</div></li>
				<li><span>❀</span><div><strong>Complete beauty care</strong>Hair, nails, skin &amp; body in one place</div></li>
				<li><span>⌂</span><div><strong>Prime Rabai Road location</strong>2nd floor, TJ&amp;U Fitness Complex</div></li>
				<li><span>◷</span><div><strong>Open six days</strong>Mon–Sat, 8 am to 8 pm</div></li>
			</ul>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

/*
 * "Your visit": a scroll story from the front desk to walking out glowing. The photo column stays put while the
 * steps scroll past; each step brings its own photo in. On phones the photo sits in each step instead.
 */
const AG_VISIT = [
	'arrive'    => [ 'Arrive', 'Up the stairs, past the gym, to the 2nd floor', 'The front desk welcomes you in and checks your booking. Running late? Call ahead and we\'ll hold your slot if the next client allows.' ],
	'consult'   => [ 'Talk it through', 'A minute to understand your skin, hair or aches', 'Before anything starts, your therapist asks about your routine, allergies and what you want to walk out with.' ],
	'robe'      => [ 'Slip into a robe', 'Robes, towels, caps and a shower are ready', 'Leave the week at the door. You only need to bring yourself.' ],
	'treatment' => [ 'Your treatment', 'Private rooms, soft light, warm towels', 'A facial in our facial room, a massage or Moroccan bath in the body rooms, or a seat at the manicure bar.' ],
	'glow'      => [ 'Walk out glowing', 'Pay after, by M-Pesa or cash', 'Nothing is paid online. Book your next visit at the desk, or send us a photo of your glow on WhatsApp.' ],
];

add_shortcode( 'ag_journey', function () {
	$steps = $photos = '';
	$i     = 0;
	foreach ( AG_VISIT as $key => [ $title, $sub, $text ] ) {
		$src     = esc_url( ag_photo( 'visit-' . $key ) );
		$photos .= sprintf( '<img src="%1$s" alt="" width="720" height="960" loading="lazy" data-ag-step-img="%2$d"%3$s>', $src, $i, $i ? '' : ' class="is-on"' );
		$steps  .= sprintf(
			'<li class="ag-journey__step%1$s" data-ag-step="%2$d"><img class="ag-journey__inline" src="%3$s" alt="" width="720" height="960" loading="lazy"><span class="ag-journey__num">%4$s</span><h3>%5$s</h3><p class="ag-journey__sub">%6$s</p><p>%7$s</p></li>',
			$i ? '' : ' is-on',
			$i,
			$src,
			sprintf( '%02d', $i + 1 ),
			esc_html( $title ),
			esc_html( $sub ),
			esc_html( $text )
		);
		$i++;
	}
	return '<div class="ag-journey" data-ag-journey><div class="ag-journey__media" aria-hidden="true"><div class="ag-journey__frame">' . $photos . '</div><div class="ag-journey__progress"><i></i></div></div><ol class="ag-journey__steps">' . $steps . '</ol></div>';
} );

// The full price list: a tab per menu, a row per treatment option with its time, price and a Book button.
add_shortcode( 'ag_price_list', function () {
	$cats = ag_categories( true );
	if ( ! $cats ) {
		return '';
	}
	$h = '<div class="ag-prices" data-ag-prices><div class="ag-prices__tabs" role="tablist">';
	foreach ( $cats as $i => $t ) {
		$h .= '<button type="button" role="tab" aria-selected="' . ( $i ? 'false' : 'true' ) . '" data-ag-tab="' . esc_attr( $t->slug ) . '"' . ( $i ? '' : ' class="is-on"' ) . '>' . esc_html( $t->name ) . '</button>';
	}
	$h .= '</div>';
	foreach ( $cats as $i => $t ) {
		$h .= '<div class="ag-prices__pane" role="tabpanel" data-ag-pane="' . esc_attr( $t->slug ) . '"' . ( $i ? ' hidden' : '' ) . '>';
		foreach ( ag_products_in( $t->slug ) as $p ) {
			$time = (string) get_post_meta( $p->get_id(), '_ag_time', true );
			$from = ag_is_quote( $p->get_id() );
			$h   .= '<div class="ag-prices__group"><div class="ag-prices__head"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ) . '</a><div><h3><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a></h3><p>' . esc_html( wp_strip_all_tags( $p->get_short_description() ) ) . '</p></div></div><ul>';
			foreach ( ag_options( $p ) as $o ) {
				$label = $o['label'] !== '' ? $o['label'] : $p->get_name();
				$h    .= '<li><span class="ag-prices__name">' . esc_html( $label ) . ( $time ? '<small>' . esc_html( $time ) . '</small>' : '' ) . '</span><span class="ag-prices__dots" aria-hidden="true"></span><b>' . ( $from && $o['label'] === '' ? 'from ' : '' ) . esc_html( ag_money( $o['price'] ) ) . '</b><button type="button" class="ag-prices__book" data-ag-add="' . (int) $o['id'] . '" aria-label="' . esc_attr( 'Book ' . $label ) . '">Book</button></li>';
			}
			$h .= '</ul></div>';
		}
		$h .= '</div>';
	}
	return $h . '<p class="ag-small ag-prices__foot">Prices in KSh from our own price list. Times are typical and vary with hair length and the look you choose.</p></div>';
} );

// The booking engine: treatments × extras × day & time × your details, with a live total. ag.js does the rest.
add_shortcode( 'ag_booking', function () {
	$b = ag_booking_data();
	if ( ! $b['cats'] ) {
		return '';
	}
	$opt = fn( $v, $label ) => '<option value="' . esc_attr( $v ) . '">' . esc_html( $label ) . '</option>';
	ob_start();
	?>
	<form class="ag-book" data-ag-booking novalidate>
		<ol class="ag-book__steps" aria-hidden="true"><li class="is-on">Treatment</li><li>Extras</li><li>Day &amp; time</li><li>Your details</li></ol>
		<div class="ag-book__grid">
			<div class="ag-book__main">
				<fieldset class="ag-book__step" data-step="1">
					<legend><span>1</span> Choose your treatments</legend>
					<div class="ag-book__cats" role="tablist">
						<?php foreach ( $b['cats'] as $i => $c ) : ?>
							<button type="button" role="tab" data-ag-cat="<?php echo esc_attr( $c['slug'] ); ?>"<?php echo $i ? '' : ' class="is-on"'; ?>><?php echo esc_html( $c['name'] ); ?></button>
						<?php endforeach; ?>
					</div>
					<?php foreach ( $b['cats'] as $i => $c ) : ?>
						<div class="ag-book__items" data-ag-cat-pane="<?php echo esc_attr( $c['slug'] ); ?>"<?php echo $i ? ' hidden' : ''; ?>>
							<?php foreach ( $c['items'] as $it ) : ?>
								<label><input type="checkbox" name="item" value="<?php echo (int) $it['id']; ?>"><span><strong><?php echo esc_html( $it['opt'] !== '' ? $it['opt'] : $it['name'] ); ?></strong><?php if ( $it['opt'] !== '' ) : ?><em><?php echo esc_html( $it['name'] ); ?></em><?php endif; ?><small><?php echo esc_html( $it['time'] ); ?></small></span><b><?php echo ( $it['from'] && $it['opt'] === '' ? 'from ' : '' ) . esc_html( ag_money( $it['price'] ) ); ?></b></label>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</fieldset>

				<fieldset class="ag-book__step" data-step="2">
					<legend><span>2</span> Add pampering extras</legend>
					<div class="ag-book__addons">
						<?php foreach ( $b['addons'] as $a ) : ?>
							<label><input type="checkbox" name="addon" value="<?php echo (int) $a['id']; ?>"><span><?php echo esc_html( $a['name'] ); ?></span><b>+ <?php echo esc_html( ag_money( $a['price'] ) ); ?></b></label>
						<?php endforeach; ?>
					</div>
				</fieldset>

				<fieldset class="ag-book__step" data-step="3">
					<legend><span>3</span> Day &amp; time</legend>
					<div class="ag-book__fields">
						<label>Preferred day<select name="date" required><option value="">Choose a day</option><?php foreach ( $b['dates'] as $k => $v ) echo $opt( $k, $v ); ?></select></label>
						<label>Who's coming<select name="guests"><?php foreach ( AG_GUESTS as $k => $v ) echo $opt( $k, $v ); ?></select></label>
					</div>
					<div class="ag-book__slots" role="radiogroup" aria-label="Time of day">
						<?php foreach ( AG_SLOTS as $k => $v ) : ?>
							<label><input type="radio" name="slot" value="<?php echo esc_attr( $k ); ?>"><span><?php echo esc_html( $v ); ?></span></label>
						<?php endforeach; ?>
					</div>
				</fieldset>

				<fieldset class="ag-book__step" data-step="4">
					<legend><span>4</span> Your details</legend>
					<div class="ag-book__fields">
						<label>Full name<input type="text" name="name" autocomplete="name" required></label>
						<label>Phone number<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
						<label>Email <em>(optional)</em><input type="email" name="email" autocomplete="email"></label>
					</div>
					<label class="ag-book__notes">Special preferences <em>(optional)</em><textarea name="notes" rows="2" placeholder="e.g. sensitive skin, a female therapist, the nail colour you want, your hair length"></textarea></label>
				</fieldset>
			</div>

			<aside class="ag-book__summary" aria-live="polite">
				<p class="ag-book__label">Your glow session</p>
				<ul class="ag-book__lines" data-ag-book-lines><li class="ag-book__empty">Choose a treatment to see your total.</li></ul>
				<div class="ag-book__total"><span>Subtotal</span><strong data-ag-book-total>KSh 0</strong></div>
				<p class="ag-book__when" data-ag-book-when></p>
				<p class="ag-small" data-ag-book-note>Nothing is paid online: you pay after your treatment, by M-Pesa or cash.</p>
				<button type="button" class="wp-element-button ag-book__reserve" data-ag-book-reserve>Reserve my appointment</button>
				<a class="ag-wa-order ag-book__wa" data-ag-book-wa href="<?php echo esc_url( ag_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo AG_WA_ICON; ?>Send booking summary to WhatsApp</a>
			</aside>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Gift voucher maker: amount, occasion, names and a message on a live voucher card.
add_shortcode( 'ag_voucher', function () {
	$v = ag_product( 'gift-voucher' );
	if ( ! $v ) {
		return '';
	}
	$amounts = ag_options( $v );
	$sel     = fn( $name, array $opts ) => '<select name="' . $name . '">' . implode( '', array_map( fn( $o ) => '<option>' . esc_html( $o ) . '</option>', $opts ) ) . '</select>';
	ob_start();
	?>
	<form class="ag-voucher" data-ag-voucher novalidate>
		<div class="ag-voucher__form">
			<p class="ag-voucher__label">Amount</p>
			<div class="ag-voucher__amounts" role="radiogroup" aria-label="Voucher amount">
				<?php foreach ( $amounts as $i => $o ) : ?>
					<label><input type="radio" name="amount" value="<?php echo (int) $o['id']; ?>" data-price="<?php echo esc_attr( $o['price'] ); ?>"<?php echo $i === 2 ? ' checked' : ''; ?>><span><?php echo esc_html( ag_money( $o['price'] ) ); ?></span></label>
				<?php endforeach; ?>
			</div>
			<div class="ag-book__fields">
				<label>Occasion<?php echo $sel( 'occasion', [ 'Birthday', 'Anniversary', 'Bridal shower', 'Thank you', 'Mother\'s Day', 'Just because' ] ); ?></label>
				<label>Send it to<?php echo $sel( 'send', [ 'Me, so I can give it', 'Them, on WhatsApp' ] ); ?></label>
				<label>For<input type="text" name="to" placeholder="Their name" maxlength="40"></label>
				<label>From<input type="text" name="from" placeholder="Your name" maxlength="40"></label>
			</div>
			<label class="ag-book__notes">Your message<textarea name="message" rows="2" maxlength="160" placeholder="Happy birthday! Enjoy a day just for you."></textarea></label>
			<div class="ag-voucher__actions">
				<button type="button" class="wp-element-button" data-ag-voucher-add>Add voucher to my order</button>
				<a class="ag-wa-order" data-ag-voucher-wa href="<?php echo esc_url( ag_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo AG_WA_ICON; ?>Order on WhatsApp</a>
			</div>
			<p class="ag-small">Paid by M-Pesa before we send it. Valid for 6 months on any treatment or package.</p>
		</div>
		<div class="ag-voucher__card" aria-hidden="true">
			<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/emblem.png' ); ?>" alt="" width="320" height="276">
			<p class="ag-voucher__brand">Aura Glow · Spa &amp; Salon</p>
			<p class="ag-voucher__occasion" data-ag-v-occasion>Birthday</p>
			<p class="ag-voucher__amount" data-ag-v-amount>KSh 5,000</p>
			<p class="ag-voucher__to"><span data-ag-v-to>For someone special</span></p>
			<p class="ag-voucher__msg" data-ag-v-msg>Happy birthday! Enjoy a day just for you.</p>
			<p class="ag-voucher__from" data-ag-v-from></p>
			<p class="ag-voucher__fine">Valid 6 months · any treatment · TJ&amp;U Fitness Complex, 2nd floor, Rabai Road</p>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Category chips above shop, category and search pages.
function ag_chip( $label, $url, $on, $count = null ) {
	return sprintf( '<a class="ag-chip%s" href="%s">%s%s</a>', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}
add_shortcode( 'ag_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h       = '<nav class="ag-filters" aria-label="Filter treatments">' . ag_chip( 'All treatments', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( ag_categories( true ) as $t ) {
		$h .= ag_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	return $h . '</nav>';
} );

// Studio clips: muted loops from their own reels, each linking to its treatment.
add_shortcode( 'ag_clips', function () {
	$clips = [
		[ 'hydra', 'HydraFacial', 'hydrafacial' ],
		[ 'massage', 'Deep tissue massage', 'massage' ],
		[ 'moroccan', 'Moroccan bath', 'moroccan-bath' ],
		[ 'jelly', 'Jelly soak pedicure', 'jelly-soak-pedicure' ],
		[ 'nails', 'Manicure', 'manicure' ],
		[ 'braids', 'Knotless braids', 'braids' ],
	];
	$h = '<div class="ag-clips">';
	foreach ( $clips as [ $clip, $label, $slug ] ) {
		if ( ! file_exists( get_stylesheet_directory() . '/assets/clips/' . $clip . '.mp4' ) ) {
			continue;
		}
		$p  = ag_product( $slug );
		$h .= '<a class="ag-clip" href="' . esc_url( $p ? $p->get_permalink() : '#' ) . '"><video src="' . esc_url( ag_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', ag_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="none"></video><span>' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</div>';
} );

// Gallery: the rooms (from their studio tour reel) and recent looks (from their posts), with a lightbox.
add_shortcode( 'ag_gallery', function () {
	$rooms = [ 'tour-desk' => 'Front desk', 'tour-facial' => 'Facial room', 'tour-hydra' => 'HydraFacial station', 'tour-massage' => 'Massage room', 'tour-salon' => 'Salon', 'tour-sinks' => 'Wash basins', 'tour-manicure' => 'Manicure bar', 'tour-pedicure' => 'Pedicure chairs' ];
	$looks = [ 'look-knotless' => 'Knotless braids', 'look-gold-tips' => 'Gold-foil French tips', 'look-mask' => 'LED mask after a HydraFacial', 'look-boho' => 'Boho braids', 'look-pedi' => 'Spa pedicure', 'look-twists' => 'Spring twists', 'look-scrub' => 'Moroccan bath', 'look-red' => 'Red box braids' ];
	$tile  = fn( $name, $label, $cls ) => '<figure class="' . $cls . '"><button type="button" data-ag-lightbox="' . esc_url( ag_photo( $name ) ) . '" data-ag-caption="' . esc_attr( $label ) . '"><img src="' . esc_url( ag_photo( $name ) ) . '" alt="' . esc_attr( $label . ' at Aura Glow' ) . '" loading="lazy" width="720" height="720"></button><figcaption>' . esc_html( $label ) . '</figcaption></figure>';
	$h     = '<div class="ag-gallery__tabs" role="tablist"><button type="button" class="is-on" data-ag-gtab="rooms">The sanctuary</button><button type="button" data-ag-gtab="looks">Recent looks</button></div>';
	$h    .= '<div class="ag-gallery ag-gallery--rooms" data-ag-gpane="rooms">';
	foreach ( $rooms as $n => $l ) {
		$h .= $tile( $n, $l, 'ag-gallery__item' );
	}
	$h .= '</div><div class="ag-gallery ag-gallery--looks" data-ag-gpane="looks" hidden>';
	foreach ( $looks as $n => $l ) {
		$h .= $tile( $n, $l, 'ag-gallery__item' );
	}
	return '<div class="ag-gallery-wrap">' . $h . '</div></div>';
} );

// Seen on Instagram: what clients and partners did at Aura Glow, from their own posts (they have no reviews online yet).
add_shortcode( 'ag_seen', function () {
	$cards = [
		[ 'look-mask', 'HydraFacial', 'Deep cleanse, exfoliation and intense hydration: instant glow in one session.', 'DN5KWikCDIg' ],
		[ 'look-massage', 'Creators reset here', 'Content creator @bymohmck chose Aura Glow for a deep tissue massage to relax and recharge.', 'DC9Fa90oyIf' ],
		[ 'look-twists', 'Two pros, one crown', 'Locs retouched, treated and twisted at Aura Glow, the hairline finished by Double Jay Barbershop in the same building.', 'DK_hiD_I4EI' ],
		[ 'look-pedi', 'More than a pedicure', 'Soothing scrubs and a relaxing massage: the Aura Glow pedicure, filmed with @sheekola.', 'DIRQHfiog7U' ],
	];
	$h = '<div class="ag-seen">';
	foreach ( $cards as [ $img, $title, $text, $code ] ) {
		$h .= '<a class="ag-seen__card" href="' . esc_url( 'https://www.instagram.com/p/' . $code . '/' ) . '" target="_blank" rel="noopener"><img src="' . esc_url( ag_photo( $img ) ) . '" alt="" loading="lazy" width="720" height="900"><span class="ag-seen__txt"><strong>' . esc_html( $title ) . '</strong><span>' . esc_html( $text ) . '</span><em>View on Instagram →</em></span></a>';
	}
	return $h . '</div>';
} );

// Instagram strip in the footer: their latest looks (static photos from their posts), each linking to the profile.
add_shortcode( 'ag_insta', function () {
	$h = '<div class="ag-insta">';
	foreach ( [ 'look-gold-tips' => 'Gold-tipped nails', 'look-knotless' => 'Knotless braids', 'look-mask' => 'A facial mask', 'look-pedi' => 'A pedicure' ] as $n => $alt ) {
		$h .= '<a href="' . esc_url( AG_IG ) . '" target="_blank" rel="noopener" aria-label="Aura Glow on Instagram"><img src="' . esc_url( ag_photo( $n ) ) . '" alt="' . esc_attr( $alt . ' at Aura Glow Spa & Salon, Buruburu' ) . '" loading="lazy" width="720" height="900"></a>';
	}
	return $h . '</div>';
} );

// Details pop-up and lightbox (filled in by ag.js), and the floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<dialog id="ag-qv" class="ag-dialog ag-qv" aria-label="Treatment details"><form method="dialog"><button class="ag-dialog__close" aria-label="Close">×</button></form><div data-ag-qv-body></div></dialog>';
	echo '<dialog id="ag-lightbox" class="ag-dialog ag-lightbox" aria-label="Photo"><form method="dialog"><button class="ag-dialog__close" aria-label="Close">×</button></form><img alt=""><p></p></dialog>';
	echo '<a class="ag-wa-float" href="' . esc_url( ag_wa_link( 'Hi Aura Glow, I\'d like to book an appointment:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with Aura Glow Spa & Salon on WhatsApp">' . AG_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart (the appointment), checkout, confirmation
 * ---------------------------------------------------------------------- */

function ag_cart_note_html() {
	return '<div class="ag-cart-note"><strong>Next:</strong> choose the day and the time of day. Nothing is paid online: you pay after your treatment.</div>';
}
function ag_wa_cart_html() {
	return '<button type="button" class="ag-wa-cart" data-ag-wa-cart>' . AG_WA_ICON . 'Send booking summary to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => ag_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . ag_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', ag_cart_note_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="ag-wa-cart-wrap">' . ag_wa_cart_html() . '</div>' );

// Appointment words on the cart and checkout buttons.
add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Confirm my appointment' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Choose day & time' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your appointment' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Book now' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View appointment' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact details', 'We send your appointment confirmation here.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Your name & phone', 'So we can call or WhatsApp to confirm.' ],
		'woocommerce/checkout-additional-information-block' => [ 'Your appointment', 'The day, the time of day, who is coming and any preferences.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is paid online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// The appointment comes before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

// "Pairs beautifully with" is shown next to the button, so skip WooCommerce's own upsell row.
add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

// The photo slider's height animation makes the page jump while it loads (layout shift); the photos are all square anyway.
add_filter( 'woocommerce_single_product_carousel_options', fn( $o ) => [ 'smoothHeight' => false ] + $o );

/** The next three weeks as booking days, Sundays left out (closed): Y-m-d => "Thu 8 Oct". */
function ag_booking_dates() {
	$out = [];
	$day = new DateTime( 'today', wp_timezone() );
	for ( $i = 0; $i < 22; $i++ ) {
		if ( $day->format( 'N' ) !== '7' ) {
			$out[ $day->format( 'Y-m-d' ) ] = ( $i === 0 ? 'Today, ' : ( $i === 1 ? 'Tomorrow, ' : '' ) ) . $day->format( 'D j M' );
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

// What the spa needs to know: field => [ label, short label, options (null = text), required ].
function ag_checkout_fields() {
	return [
		'ag/date'   => [ 'Preferred day', 'Day', ag_booking_dates(), true ],
		'ag/time'   => [ 'Time of day', 'Time', AG_SLOTS, true ],
		'ag/guests' => [ 'Who\'s coming', 'Guests', AG_GUESTS, true ],
		'ag/notes'  => [ 'Special preferences (sensitive skin, nail colour, hair length…)', 'Preferences', null, false ],
		'ag/gift'   => [ 'Gift voucher: who it\'s for and your message (vouchers only)', 'Voucher', null, false ],
	];
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( ag_checkout_fields() as $id => [ $label, , $options, $required ] ) {
		$field = [ 'id' => $id, 'label' => $label, 'location' => 'order', 'type' => $options ? 'select' : 'text', 'required' => $required ];
		if ( $options ) {
			$field['options'] = array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $options ), $options );
		}
		woocommerce_register_additional_checkout_field( $field );
	}
} );

function ag_booking_code( WC_Order $order ) {
	return 'AG-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
/** Appointment details from the checkout fields, as short label => readable value. */
function ag_booking_details( WC_Order $order ) {
	$out = [];
	foreach ( ag_checkout_fields() as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' ) {
			$out[ $label ] = $options[ $value ] ?? $value;
		}
	}
	return $out;
}
function ag_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Aura Glow, I just booked online (' . ag_booking_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . ag_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . ag_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	foreach ( ag_booking_details( $order ) as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return ag_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$d    = ag_booking_details( $order );
	$when = implode( ' · ', array_filter( [ $d['Day'] ?? '', $d['Time'] ?? '' ] ) );
	return $content . '<div class="ag-thanks"><p class="ag-thanks__code">Appointment number <strong>' . esc_html( ag_booking_code( $order ) ) . '</strong></p>' . ( $when ? '<p class="ag-thanks__when">' . esc_html( $when ) . '</p>' : '' ) . '<ol><li>We call or WhatsApp you shortly to confirm the exact time.</li><li>Come up to the 2nd floor of the TJ&amp;U Fitness Complex on Rabai Road, Buruburu Phase 1 (<a href="' . esc_url( AG_MAPS ) . '" target="_blank" rel="noopener">map</a>). Arrive 10 minutes early to settle in.</li><li>Enjoy your treatment, then pay by M-Pesa or cash at the front desk.</li></ol><a class="wp-element-button ag-wa-btn" href="' . esc_attr( ag_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . AG_WA_ICON . 'Send booking summary to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Appointment number:</strong> ' . esc_html( ag_booking_code( $order ) ) . '</p>';
} );

// Staff edit the card labels, the facts, what's included and the studio clip on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_ag_badge', 'label' => 'Card label', 'description' => 'Small label above the name, e.g. "Most booked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_ag_perk', 'label' => 'Card badge', 'description' => 'One benefit shown on the card, e.g. "No downtime".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_ag_perks', 'label' => 'Benefit badges', 'description' => 'Shown on the treatment page, separated by |, e.g. "Deep cleanse | Hydration boost".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_ag_time', 'label' => 'Time', 'description' => 'e.g. "About 60 min". Shown in the price list and the booking engine.', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_ag_clip', 'label' => 'Studio clip', 'options' => [ '' => 'None', 'hydra' => 'HydraFacial', 'massage' => 'Massage', 'moroccan' => 'Moroccan bath', 'jelly' => 'Jelly soak pedicure', 'nails' => 'Manicure', 'braids' => 'Braids' ] ] );
	woocommerce_wp_checkbox( [ 'id' => '_ag_quote', 'label' => 'Starting price', 'description' => 'Shows the price as "from", confirmed before the treatment starts.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_ag_specs', 'label' => 'Good to know', 'rows' => 5, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_ag_included', 'label' => 'What\'s included', 'rows' => 8, 'description' => 'One item per line.' ] );
	echo '<p class="form-field"><em>Treatment options (e.g. Swedish / Deep tissue): Attributes → the option list makes the variations; set each price under Variations. "Pairs beautifully with" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_ag_badge', '_ag_perk', '_ag_perks', '_ag_time', '_ag_clip' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
	$product->update_meta_data( '_ag_quote', isset( $_POST['_ag_quote'] ) ? 'yes' : 'no' ); // phpcs:ignore
	foreach ( [ '_ag_specs', '_ag_included' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan contacts: only the name and phone are needed for an appointment.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	foreach ( [ 'postcode', 'state', 'address_1', 'address_2', 'city' ] as $f ) {
		$locale['KE'][ $f ] = [ 'required' => false, 'hidden' => true ];
	}
	$locale['KE']['phone'] = [ 'required' => true ];
	return $locale;
} );

// Appointment words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'  => 'You may also love',
		'Continue shopping' => 'Keep browsing treatments',
		'Order received'    => 'Appointment received',
		'Thank you. Your order has been received.' => 'Thank you. Your appointment request has been received.',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your appointment.' : $text;
}, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// booking engine's and price list's grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|poster|data-ag-lightbox)="/(?!/)#', '$1="' . $home, $content );
} );

require __DIR__ . '/seo.php';
